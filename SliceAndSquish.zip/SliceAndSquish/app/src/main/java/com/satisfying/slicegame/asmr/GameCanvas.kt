package com.satisfying.slicegame.asmr

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.changedToDown
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

private const val PI_F = 3.1415927f
private const val DEG = 180f / PI_F

interface Feedback {
    fun sound(s: Snd, rate: Float = 1f, vol: Float = 1f)
    fun haptic(strong: Boolean = false)
    fun loopStart(s: Snd)
    fun loopStop(s: Snd)
}

private fun alpha(c: Int, a: Float): Int = ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24) or (c and 0xFFFFFF)
private fun mix(a: Int, b: Int, t: Float): Int {
    val r = (((a shr 16) and 255) * (1 - t) + ((b shr 16) and 255) * t).toInt()
    val g = (((a shr 8) and 255) * (1 - t) + ((b shr 8) and 255) * t).toInt()
    val bl = ((a and 255) * (1 - t) + (b and 255) * t).toInt()
    return (255 shl 24) or (r shl 16) or (g shl 8) or bl
}
private fun rnd(a: Float, b: Float) = a + Random.nextFloat() * (b - a)

// ------------------------------------------------------------------ small data classes
class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    var life: Float, val maxLife: Float, val size: Float, val color: Int,
    val gravity: Float, val kind: Int, var rot: Float = 0f, var vr: Float = 0f, val bounce: Boolean = false
)
class FloatText(var x: Float, var y: Float, val text: String, val color: Int, var life: Float, val scale: Float = 1f)
class TrailPt(val x: Float, val y: Float, var age: Float)
class Flash(val x1: Float, val y1: Float, val x2: Float, val y2: Float, var life: Float, val color: Int)
class Strand(val a: Piece, val b: Piece, var life: Float, val color: Int)
class Ripple(val x: Float, val y: Float, var age: Float)
class Seg(val x1: Float, val y1: Float, val x2: Float, val y2: Float, var a: Float)
class CrushObj(val x: Float, val y: Float, val w: Float, val h: Float, val kind: CrushKind, val rot: Float) {
    var squash = 0f
    var crushed = false
    var pop = 0f
}
class Drop(var x: Float, var y: Float, var vx: Float, var vy: Float, var prev: Drop?) { var alive = true }
class Grab(val x0: Float, val y0: Float, val w: FloatArray) { var cx = x0; var cy = y0; var maxD = 0f }

/** Shared procedural texture dots (x, y, r) in object texture space. */
class Tex(seed: Int) {
    val dots = FloatArray(110 * 3)
    init {
        val r = Random(seed)
        for (i in 0 until 110) {
            dots[i * 3] = r.nextFloat() * 760f - 380f
            dots[i * 3 + 1] = r.nextFloat() * 620f - 310f
            dots[i * 3 + 2] = 2f + r.nextFloat() * 8f
        }
    }
}

class Piece(
    var cx: Float, var cy: Float, var local: List<Offset>, var angle: Float,
    val mat: Material, val tex: Tex, var texOff: Offset
) {
    var vx = 0f; var vy = 0f; var av = 0f
    var floating = false; var baseCy = cy; var bob = 0f
    var resting = false; var targetAngle = 0f; var restTime = 0f
    var wobble = 0f; var fade = 1f; var dying = false
    var id = 0; var area = 0f; var radius = 0f

    fun recompute() {
        area = polygonArea(local)
        var m = 0f
        for (p in local) m = max(m, hypot(p.x, p.y))
        radius = m
    }
    fun worldPoly(): List<Offset> {
        val c = cos(angle); val s = sin(angle)
        return local.map { Offset(cx + it.x * c - it.y * s, cy + it.x * s + it.y * c) }
    }
    fun lowest(): Float {
        val s = sin(angle); val c = cos(angle)
        var m = -1e9f
        for (p in local) m = max(m, p.x * s + p.y * c)
        return m
    }
    fun computeRestAngle() {
        var best = angle
        var bestD = Float.MAX_VALUE
        val n = local.size
        for (i in 0 until n) {
            val a = local[i]; val b = local[(i + 1) % n]
            val ex = b.x - a.x; val ey = b.y - a.y
            val el = sqrt(ex * ex + ey * ey)
            if (el < 1f) continue
            var nx = ey / el; var ny = -ex / el
            if (nx * a.x + ny * a.y < 0f) { nx = -nx; ny = -ny }
            val t = (-(a.x * ex + a.y * ey)) / (el * el)
            if (t < 0.05f || t > 0.95f) continue
            val theta = PI_F / 2f - atan2(ny, nx)
            var d = theta - angle
            while (d > PI_F) d -= 2f * PI_F
            while (d < -PI_F) d += 2f * PI_F
            if (abs(d) < bestD) { bestD = abs(d); best = angle + d }
        }
        targetAngle = best
    }
}

// ------------------------------------------------------------------ the world
class GameWorld(
    val level: LevelDef, private val fb: Feedback, private val store: GameStore,
    assets: android.content.res.AssetManager? = null
) {

    companion object {
        const val W = 1080f
        const val H = 1920f
        const val GRAV = 0.5f
        const val FLOOR = 1560f
        const val CUT_MIN = 1500f
        // pour
        const val JX0 = 330f; const val JX1 = 750f; const val JB = 1640f; const val JT = 1180f
        const val JC = 21; const val JCAP = 380f
        const val NOZ_Y = 330f
    }

    // ---- exposed HUD state
    var score by mutableIntStateOf(0)
    var coins by mutableIntStateOf(0)
    var progress by mutableIntStateOf(0)
    var completed by mutableStateOf(false)
    var showWin by mutableStateOf(false)
    var stars = 1
    var perfects = 0
    var elapsed = 0f
    var knife: Knife = Knife.values()[store.knife.coerceIn(0, 3)]
    var tilt = 0f

    private var time = 0f
    private var winTimer = 0f
    private var combo = 0
    private var cuts = 0

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val path = Path()
    private val rect = RectF()
    private var bgShader: LinearGradient? = null

    private val particles = ArrayList<Particle>()
    private val texts = ArrayList<FloatText>()
    private val trail = ArrayList<TrailPt>()
    private val flashes = ArrayList<Flash>()
    private var floorY = FLOOR

    // slicing
    private val pieces = ArrayList<Piece>()
    private val strands = ArrayList<Strand>()
    private val entry = HashMap<Int, Offset>()
    private val last = HashMap<Int, Offset>()
    private var nextId = 1
    private var respawn = 0f
    private var s3d: Slice3D? = null
    // hand + knife overlay
    private var handX = 540f; private var handY = 900f
    private var handAng = 1.9f; private var handTarget = 1.9f; private var handA = 0f

    // squish
    private val bn = 56
    private val rx = FloatArray(bn); private val ry = FloatArray(bn)
    private val bx = FloatArray(bn); private val by = FloatArray(bn)
    private val bvx = FloatArray(bn); private val bvy = FloatArray(bn)
    private val grabs = HashMap<Int, Grab>()
    private var squishes = 0
    private var squishSndT = 0f

    // tap
    private val ripples = ArrayList<Ripple>()
    private val segs = ArrayList<Seg>()
    private val surface = RectF(90f, 380f, 990f, 1520f)
    private var tapPoints = 0
    private var scratchAcc = 0f
    private var scratchDown = -1
    private var sinceMove = 0f
    private var scratchLoop = false
    private var hapT = 0f

    // crunch
    private val objs = ArrayList<CrushObj>()
    private var crushPtr = -1
    private var plateX = W / 2; private var plateY = -200f; private var targetY = -200f; private var targetX = W / 2
    private var crushed = 0

    // pour
    private val drops = ArrayList<Drop>()
    private val jarH = FloatArray(JC)
    private val spill = FloatArray(54)
    private var nozX = W / 2; private var targetNozX = W / 2
    private var pourPtr = -1
    private var pouring = false
    private var lastDrop: Drop? = null
    private var emitAcc = 0f
    private var dripLeft = 0f
    private var dripT = 0f
    private var tiltS = 0f
    private var fluidTop = 0; private var fluidBot = 0

    init {
        when (level.type) {
            LevelType.SLICE -> {
                if (assets != null) { s3d = try { Slice3D(assets, this, level) } catch (e: Throwable) { null } }
                if (s3d == null) spawnBlock()
            }
            LevelType.SQUISH -> {
                for (i in 0 until bn) {
                    val a = i * 2f * PI_F / bn
                    rx[i] = W / 2 + cos(a) * 300f; ry[i] = 900f + sin(a) * 250f
                    bx[i] = rx[i]; by[i] = ry[i]
                }
            }
            LevelType.CRUNCH -> { floorY = 1620f; layoutCrush() }
            LevelType.POUR -> {
                val v = (level.number / 10) % 3
                fluidTop = intArrayOf(0xFFFFD25A.toInt(), 0xFF7CFF5B.toInt(), 0xFFFF5BC8.toInt())[v]
                fluidBot = intArrayOf(0xFFE08A00.toInt(), 0xFF1DBE45.toInt(), 0xFFB0127A.toInt())[v]
            }
            else -> {}
        }
    }

    // ================================================================== input
    fun pointerDown(id: Int, x: Float, y: Float) {
        if (completed) return
        when (level.type) {
            LevelType.SLICE -> {
                val s3 = s3d
                if (s3 != null) { trail.add(TrailPt(x, y, 0f)); s3.down(id, x, y) }
                else { last[id] = Offset(x, y); trail.add(TrailPt(x, y, 0f)); handX = x; handY = y }
            }
            LevelType.SQUISH -> squishDown(id, x, y)
            LevelType.TAP -> tapDown(id, x, y)
            LevelType.CRUNCH -> if (crushPtr == -1) { crushPtr = id; targetX = x; targetY = y }
            LevelType.POUR -> if (pourPtr == -1) { pourPtr = id; targetNozX = x }
        }
    }

    fun pointerMove(id: Int, x: Float, y: Float) {
        if (completed) return
        when (level.type) {
            LevelType.SLICE -> {
                val s3 = s3d
                if (s3 != null) { trail.add(TrailPt(x, y, 0f)); s3.move(id, x, y); return }
                val a = last[id] ?: return
                val b = Offset(x, y)
                if ((b - a).getDistance() >= 3f) {
                    handleSwipe(a, b)
                    trail.add(TrailPt(x, y, 0f))
                    last[id] = b
                    handX = x; handY = y
                    val mvx = b.x - a.x; val mvy = b.y - a.y
                    if (hypot(mvx, mvy) > 2f) {
                        val back = atan2(-mvy, -mvx)
                        handTarget = atan2(max(sin(back), 0.3f), cos(back))
                    }
                }
            }
            LevelType.SQUISH -> grabs[id]?.let {
                it.cx = x; it.cy = y
                it.maxD = max(it.maxD, hypot(x - it.x0, y - it.y0))
                squishSndT -= 1f
                if (squishSndT <= 0f) { squishSndT = 14f; fb.sound(Snd.SQUISH, rnd(0.8f, 1.1f), 0.5f); fb.haptic() }
            }
            LevelType.TAP -> tapMove(id, x, y)
            LevelType.CRUNCH -> if (id == crushPtr) { targetX = x; targetY = y }
            LevelType.POUR -> if (id == pourPtr) targetNozX = x
        }
    }

    fun pointerUp(id: Int, x: Float, y: Float) {
        when (level.type) {
            LevelType.SLICE -> { s3d?.up(id); last.remove(id); entry.clear() }
            LevelType.SQUISH -> squishUp(id)
            LevelType.TAP -> if (id == scratchDown) { scratchDown = -1; stopScratch() }
            LevelType.CRUNCH -> if (id == crushPtr) { crushPtr = -1; targetY = -200f }
            LevelType.POUR -> if (id == pourPtr) pourPtr = -1
        }
    }

    // ================================================================== update
    fun update(dt: Float) {
        val f = dt * 60f
        time += dt
        if (!completed) elapsed += dt
        when (level.type) {
            LevelType.SLICE -> updateSlice(dt, f)
            LevelType.SQUISH -> updateSquish(dt, f)
            LevelType.TAP -> updateTap(dt, f)
            LevelType.CRUNCH -> updateCrunch(dt, f)
            LevelType.POUR -> updatePour(dt, f)
        }
        updateParticles(dt, f)
        for (t in trail) t.age += dt
        trail.removeAll { it.age > 0.28f }
        for (fl in flashes) fl.life -= dt
        flashes.removeAll { it.life <= 0f }
        for (t in texts) { t.y -= 40f * dt; t.life -= dt }
        texts.removeAll { it.life <= 0f }
        if (completed && !showWin) {
            winTimer += dt
            if (winTimer > 1.0f) showWin = true
        }
    }

    private fun updateParticles(dt: Float, f: Float) {
        val it = particles.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.x += p.vx * f; p.y += p.vy * f; p.vy += p.gravity * f; p.rot += p.vr * f
            p.life -= dt
            if (p.bounce && p.y > floorY) {
                p.y = floorY; p.vy = -p.vy * 0.35f; p.vx *= 0.7f; p.vr *= 0.6f
                if (abs(p.vy) < 1.5f) { p.vy = 0f; p.vx *= 0.8f }
            }
            if (p.life <= 0f) it.remove()
        }
        if (particles.size > 900) particles.subList(0, particles.size - 900).clear()
    }

    private fun burst(x: Float, y: Float, n: Int, color: Int, speed: Float, size: Float = 7f,
                      kind: Int = 0, grav: Float = 0.3f, life: Float = 0.8f, bounce: Boolean = false) {
        for (i in 0 until n) {
            val a = rnd(0f, 2f * PI_F); val s = rnd(0.3f, 1f) * speed
            particles.add(Particle(x, y, cos(a) * s, sin(a) * s, life * rnd(0.6f, 1f), life, size * rnd(0.6f, 1.2f),
                color, grav, kind, rnd(0f, 6f), rnd(-0.3f, 0.3f), bounce))
        }
    }
    private fun ring(x: Float, y: Float, color: Int, r: Float = 140f) {
        particles.add(Particle(x, y, 0f, 0f, 0.5f, 0.5f, r, color, 0f, 2))
    }
    private fun say(x: Float, y: Float, s: String, color: Int, scale: Float = 1f) {
        texts.add(FloatText(x, y, s, color, 1.0f, scale))
    }
    private fun addScore(n: Int) { score += n }
    private fun addCoins(n: Int) { coins += n; store.addCoins(n) }

    private fun finish() {
        if (completed) return
        completed = true
        addCoins(20)
        addScore(200)
        stars = when (level.type) {
            LevelType.SLICE -> if (perfects >= 3) 3 else if (perfects >= 1) 2 else 1
            else -> if (elapsed < 40f) 3 else if (elapsed < 80f) 2 else 1
        }
        fb.haptic(true)
        for (i in 0 until 5) burst(rnd(150f, 930f), rnd(500f, 1100f), 26,
            intArrayOf(0xFF22F0FF.toInt(), 0xFFFF2E9A.toInt(), 0xFFB6FF3B.toInt(), 0xFFFFD83B.toInt(), 0xFF8A4DFF.toInt())[i], 14f, 9f, 0, 0.25f, 1.3f)
        say(W / 2, 700f, "LEVEL CLEAR!", 0xFFFFD83B.toInt(), 1.5f)
    }

    // ================================================================== SLICING
    private fun roundedRect(w: Float, h: Float, r: Float, seg: Int): List<Offset> {
        val pts = ArrayList<Offset>()
        val cs = arrayOf(Offset(w / 2 - r, h / 2 - r), Offset(-w / 2 + r, h / 2 - r), Offset(-w / 2 + r, -h / 2 + r), Offset(w / 2 - r, -h / 2 + r))
        for (k in 0 until 4) for (s in 0..seg) {
            val a = (k * 90f + 90f * s / seg) / DEG
            pts.add(Offset(cs[k].x + cos(a) * r, cs[k].y + sin(a) * r))
        }
        return pts
    }
    private fun ellipse(rx: Float, ry: Float, n: Int): List<Offset> =
        (0 until n).map { val a = it * 2f * PI_F / n; Offset(cos(a) * rx, sin(a) * ry) }

    private fun spawnBlock() {
        for (p in pieces) p.dying = true
        val m = level.material
        val poly = when (m) {
            Material.SOAP -> roundedRect(560f, 380f, 40f, 5)
            Material.SAND -> roundedRect(520f, 420f, 120f, 6)
            Material.JELLY -> roundedRect(430f, 430f, 70f, 6)
            Material.CRYSTAL -> ellipse(250f, 250f, 28)
            Material.CLAY -> ellipse(310f, 230f, 28)
            Material.WOOD -> roundedRect(620f, 300f, 18f, 3)
        }
        val pc = Piece(W / 2, 800f, poly, 0f, m, Tex(level.number * 31 + nextId), Offset.Zero)
        pc.floating = true; pc.baseCy = 800f; pc.id = nextId++
        pc.recompute()
        pieces.add(pc)
    }

    private fun handleSwipe(a: Offset, b: Offset) {
        for (pc in pieces.toList()) {
            if (pc.dying || pc.area < CUT_MIN * 2f) continue
            val hits = segmentPolygonHits(a, b, pc.worldPoly())
            if (hits.size >= 2) {
                entry.remove(pc.id)
                cutPiece(pc, hits.first(), hits.last())
            } else if (hits.size == 1) {
                val e = entry[pc.id]
                if (e == null) entry[pc.id] = hits[0]
                else {
                    entry.remove(pc.id)
                    if ((e - hits[0]).getDistance() > 14f) cutPiece(pc, e, hits[0])
                }
            }
        }
    }

    private fun cutPiece(pc: Piece, p1: Offset, p2: Offset) {
        val (l, r) = slicePolygon(pc.worldPoly(), Line(p1, p2))
        if (r.size < 3) return
        val aL = polygonArea(l); val aR = polygonArea(r)
        if (aL < CUT_MIN || aR < CUT_MIN) return
        val dx = p2.x - p1.x; val dy = p2.y - p1.y
        val len = hypot(dx, dy)
        if (len < 8f) return
        val nx = -dy / len; val ny = dx / len
        val cs = cos(pc.angle); val sn = sin(pc.angle)
        val mat = pc.mat
        val kids = ArrayList<Piece>()
        for (k in 0..1) {
            val pg = if (k == 0) l else r
            val sgn = if (k == 0) 1f else -1f
            val c = polygonCentroid(pg)
            val loc = pg.map { val ox = it.x - c.x; val oy = it.y - c.y; Offset(ox * cs + oy * sn, -ox * sn + oy * cs) }
            val ddx = c.x - pc.cx; val ddy = c.y - pc.cy
            val toff = Offset(pc.texOff.x + ddx * cs + ddy * sn, pc.texOff.y - ddx * sn + ddy * cs)
            val kid = Piece(c.x, c.y, loc, pc.angle, mat, pc.tex, toff)
            kid.id = nextId++
            kid.recompute()
            kid.vx = pc.vx + nx * mat.sep * sgn
            kid.vy = pc.vy + ny * mat.sep * sgn - (if (pc.resting) 2.5f else 0f)
            if (abs(nx) < 0.5f) kid.vx += (if (c.x >= pc.cx) 1f else -1f) * 2f
            kid.av = pc.av + sgn * rnd(0.005f, 0.03f)
            kid.wobble = 1f
            kids.add(kid)
        }
        pieces.remove(pc)
        pieces.addAll(kids)
        if (mat == Material.CLAY) strands.add(Strand(kids[0], kids[1], 0.55f, mat.top))

        // ---- reward / juice
        cuts++
        val ratio = min(aL, aR) / (aL + aR)
        val perfect = ratio >= knife.perfectMin
        val mx = (p1.x + p2.x) / 2; val my = (p1.y + p2.y) / 2
        flashes.add(Flash(p1.x, p1.y, p2.x, p2.y, 0.22f, if (perfect) 0xFFFFFFFF.toInt() else knife.color))
        fb.sound(mat.cutSound, mat.rate * rnd(0.92f, 1.1f))
        if (perfect) {
            perfects++; combo++
            addScore(50 * combo); addCoins(5)
            say(mx, my - 40f, if (combo > 1) "PERFECT x$combo" else "PERFECT!", 0xFFFFD83B.toInt(), 1.2f)
            say(mx, my + 40f, "+5", 0xFFFFD83B.toInt(), 0.8f)
            for (i in 0..14) {
                val t = i / 14f
                burst(p1.x + dx * t, p1.y + dy * t, 2, if (i % 2 == 0) knife.color else 0xFFFFFFFF.toInt(), 9f, 8f, 0, 0.2f, 0.9f)
            }
            ring(mx, my, knife.color)
            fb.haptic(true)
        } else {
            combo = 0
            addScore(10)
            fb.haptic()
        }
        when (mat) {
            Material.SAND -> for (i in 0..40) {
                val t = Random.nextFloat()
                particles.add(Particle(p1.x + dx * t, p1.y + dy * t, rnd(-1.5f, 1.5f), rnd(-1f, 1f), 1.4f, 1.4f, rnd(3f, 6f),
                    mix(mat.top, mat.bottom, Random.nextFloat()), 0.5f, 4, 0f, 0f, true))
            }
            Material.CRYSTAL -> for (i in 0..18) {
                val t = Random.nextFloat()
                particles.add(Particle(p1.x + dx * t, p1.y + dy * t, rnd(-8f, 8f), rnd(-9f, 3f), 1.2f, 1.2f, rnd(10f, 20f),
                    mix(mat.top, 0xFFFFFFFF.toInt(), Random.nextFloat() * 0.6f), 0.5f, 3, rnd(0f, 6f), rnd(-0.3f, 0.3f), true))
            }
            else -> burst(mx, my, 12, mat.accent, 7f, 6f, 0, 0.3f, 0.6f)
        }
        progress = if (level.goal == GoalKind.PERFECT_CUTS) min(level.target, perfects) else min(level.target, cuts + 1)
        if (progress >= level.target) finish()
    }

    private fun updateSlice(dt: Float, f: Float) {
        s3d?.let { it.update(dt, f); return }
        var dA = handTarget - handAng
        while (dA > PI_F) dA -= 2f * PI_F
        while (dA < -PI_F) dA += 2f * PI_F
        handAng += dA * (1f - 0.75f.pow(f))
        val want = if (last.isNotEmpty() && !completed) 1f else 0f
        handA += (want - handA) * min(1f, dt * 10f)
        for (pc in pieces) {
            if (pc.floating) {
                pc.bob += dt * 2.2f
                pc.cy = pc.baseCy + sin(pc.bob) * 12f
                pc.angle = sin(pc.bob * 0.7f) * 0.03f
                continue
            }
            if (pc.dying) { pc.fade -= dt * 2.5f; continue }
            if (!pc.resting) {
                pc.vy += GRAV * f * (if (pc.mat == Material.CLAY && pc.restTime < 0.3f) 0.35f else 1f)
                pc.restTime += dt
                pc.cx += pc.vx * f; pc.cy += pc.vy * f; pc.angle += pc.av * f
                if (pc.mat == Material.CLAY) pc.vx *= 0.99f.pow(f)
                val bottom = pc.cy + pc.lowest()
                if (bottom > FLOOR) {
                    pc.cy -= bottom - FLOOR
                    if (pc.vy > 4f && pc.mat.bounce > 0.1f) {
                        pc.vy = -pc.vy * pc.mat.bounce; pc.av *= 0.5f; pc.vx *= 0.8f; pc.wobble = 1f
                    } else {
                        pc.vy = 0f; pc.av = 0f; pc.resting = true; pc.restTime = 0f
                        pc.computeRestAngle(); pc.wobble = 1f
                        burst(pc.cx, FLOOR, 5, pc.mat.accent, 4f, 5f, 4, 0.2f, 0.5f)
                    }
                }
                if (pc.cx < 60f) { pc.cx = 60f; pc.vx = abs(pc.vx) * 0.4f }
                if (pc.cx > W - 60f) { pc.cx = W - 60f; pc.vx = -abs(pc.vx) * 0.4f }
            } else {
                pc.angle += (pc.targetAngle - pc.angle) * (1f - 0.75f.pow(f))
                pc.cx += pc.vx * f; pc.vx *= 0.85f.pow(f)
                pc.cy = FLOOR - pc.lowest()
                pc.restTime += dt
                if (pc.area < CUT_MIN * 2f && pc.restTime > 3f) pc.dying = true
            }
            pc.wobble *= 0.93f.pow(f)
        }
        // soft separation between resting neighbours
        for (i in pieces.indices) for (j in i + 1 until pieces.size) {
            val a = pieces[i]; val b = pieces[j]
            if (!a.resting || !b.resting || a.dying || b.dying) continue
            val d = a.cx - b.cx
            val lim = (a.radius + b.radius) * 0.6f
            if (abs(d) < lim && abs(a.cy - b.cy) < lim) {
                val push = (lim - abs(d)) * 0.08f * f * (if (d >= 0f) 1f else -1f)
                a.cx += push; b.cx -= push
            }
        }
        pieces.removeAll { it.fade <= 0f || it.cy > H + 300f }
        if (pieces.size > 26) pieces.filter { !it.dying }.take(pieces.size - 26).forEach { it.dying = true }
        for (s in strands) s.life -= dt
        strands.removeAll { it.life <= 0f }
        if (!completed) {
            val big = pieces.any { !it.dying && it.area >= CUT_MIN * 2f }
            if (!big) { respawn += dt; if (respawn > 0.7f) { respawn = 0f; spawnBlock() } } else respawn = 0f
        }
    }

    /** Called by Slice3D after a successful 3D cut. ratio = smaller piece volume / total. */
    internal fun onCut3D(ratio: Float, p1x: Float, p1y: Float, p2x: Float, p2y: Float, flesh: Int) {
        cuts++
        val perfect = ratio >= knife.perfectMin
        val mx = (p1x + p2x) / 2f; val my = (p1y + p2y) / 2f
        flashes.add(Flash(p1x, p1y, p2x, p2y, 0.22f, if (perfect) 0xFFFFFFFF.toInt() else knife.color))
        fb.sound(Snd.CUT_SOAP, rnd(0.85f, 1.1f))
        burst(mx, my, 16, flesh, 9f, 7f, 4, 0.5f, 0.9f)
        if (perfect) {
            perfects++; combo++
            addScore(50 * combo); addCoins(5)
            say(mx, my - 40f, if (combo > 1) "PERFECT x$combo" else "PERFECT!", 0xFFFFD83B.toInt(), 1.2f)
            say(mx, my + 40f, "+5", 0xFFFFD83B.toInt(), 0.8f)
            val dx = p2x - p1x; val dy = p2y - p1y
            for (i in 0..14) {
                val t = i / 14f
                burst(p1x + dx * t, p1y + dy * t, 2, if (i % 2 == 0) knife.color else 0xFFFFFFFF.toInt(), 9f, 8f, 0, 0.2f, 0.9f)
            }
            ring(mx, my, knife.color)
            fb.haptic(true)
        } else {
            combo = 0
            addScore(10)
            fb.haptic()
        }
        progress = if (level.goal == GoalKind.PERFECT_CUTS) min(level.target, perfects) else min(level.target, cuts + 1)
        if (progress >= level.target) finish()
    }

    // ================================================================== SQUISH
    private fun squishDown(id: Int, x: Float, y: Float) {
        val w = FloatArray(bn)
        var mx = 0f
        for (i in 0 until bn) {
            val d2 = (bx[i] - x) * (bx[i] - x) + (by[i] - y) * (by[i] - y)
            w[i] = exp(-d2 / (2f * 170f * 170f)); mx = max(mx, w[i])
        }
        if (mx < 0.2f) return
        grabs[id] = Grab(x, y, w)
        fb.sound(Snd.SQUISH, rnd(0.9f, 1.15f), 0.8f); fb.haptic()
        burst(x, y, 6, level.material.accent, 4f, 5f, 0, 0.1f, 0.4f)
    }

    private fun squishUp(id: Int) {
        val g = grabs.remove(id) ?: return
        if (g.maxD > 130f && !completed) {
            squishes++
            addScore(25 * (1 + (g.maxD / 300f).toInt()))
            fb.sound(Snd.SQUISH, rnd(1.0f, 1.3f)); fb.haptic(true)
            ring(g.cx, g.cy, 0xFFB6FF3B.toInt(), 160f)
            burst(g.cx, g.cy, 18, 0xFFB6FF3B.toInt(), 9f, 7f, 0, 0.3f, 0.8f)
            say(g.cx, g.cy - 60f, "SQUISH!", 0xFFB6FF3B.toInt())
            progress = min(level.target, squishes)
            if (progress >= level.target) finish()
        }
    }

    private fun updateSquish(dt: Float, f: Float) {
        val fx = FloatArray(bn); val fy = FloatArray(bn)
        for (i in 0 until bn) {
            var ax = (rx[i] - bx[i]) * 0.10f
            var ay = (ry[i] - by[i]) * 0.10f
            for (g in grabs.values) {
                val w = g.w[i]
                if (w > 0.01f) {
                    val tx = rx[i] + (g.cx - g.x0) * 1.3f; val ty = ry[i] + (g.cy - g.y0) * 1.3f
                    ax += (tx - bx[i]) * 0.35f * w; ay += (ty - by[i]) * 0.35f * w
                }
            }
            val p = (i + bn - 1) % bn; val n = (i + 1) % bn
            ax += ((bx[p] + bx[n]) * 0.5f - bx[i]) * 0.12f
            ay += ((by[p] + by[n]) * 0.5f - by[i]) * 0.12f
            fx[i] = ax; fy[i] = ay
        }
        val damp = 0.88f.pow(f)
        for (i in 0 until bn) {
            bvx[i] = (bvx[i] + fx[i] * f) * damp; bvy[i] = (bvy[i] + fy[i] * f) * damp
            bx[i] += bvx[i] * f; by[i] += bvy[i] * f
        }
    }

    // ================================================================== TAP & SCRATCH
    private fun tapAdd(n: Int) {
        tapPoints += n
        progress = min(level.target, tapPoints)
        if (progress >= level.target) finish()
    }

    private fun tapDown(id: Int, x: Float, y: Float) {
        if (!surface.contains(x, y)) return
        ripples.add(Ripple(x, y, 0f))
        fb.sound(Snd.TAP, rnd(0.85f, 1.2f)); fb.haptic()
        burst(x, y, 8, 0xFFFF2E9A.toInt(), 6f, 6f, 0, 0.1f, 0.5f)
        addScore(5); tapAdd(1)
        scratchDown = id
        last[id] = Offset(x, y)
        sinceMove = 0f
    }

    private fun tapMove(id: Int, x: Float, y: Float) {
        if (id != scratchDown) return
        val g = last[id]
        last[id] = Offset(x, y)
        if (g == null) return
        if (!surface.contains(x, y)) { stopScratch(); return }
        val d = hypot(x - g.x, y - g.y)
        sinceMove = 0f
        if (d in 2f..40f) {
            segs.add(Seg(g.x, g.y, x, y, 1f))
            if (segs.size > 500) segs.removeAt(0)
            scratchAcc += d
            if (!scratchLoop) { scratchLoop = true; fb.loopStart(Snd.SCRATCH) }
            hapT -= 1f
            if (hapT <= 0f) { hapT = 6f; fb.haptic() }
            if (Random.nextFloat() < 0.4f) particles.add(Particle(x, y, rnd(-2f, 2f), rnd(-2f, 0f), 0.4f, 0.4f, 3f, 0xFFFFFFFF.toInt(), 0.2f, 0))
            if (scratchAcc > 110f) { scratchAcc = 0f; addScore(3); tapAdd(1) }
        } else stopScratch()
    }

    private fun stopScratch() {
        if (scratchLoop) { scratchLoop = false; fb.loopStop(Snd.SCRATCH) }
    }

    private fun updateTap(dt: Float, f: Float) {
        for (r in ripples) r.age += dt
        ripples.removeAll { it.age > 1.1f }
        sinceMove += dt
        if (scratchLoop && sinceMove > 0.12f) stopScratch()
    }

    // ================================================================== CRUNCH
    private fun layoutCrush() {
        val n = level.target
        val cols = 3
        val rows = (n + cols - 1) / cols
        val sp = min(260f, 900f / rows)
        val top = 560f
        for (i in 0 until n) {
            val r = i / cols; val c = i % cols
            val inRow = min(cols, n - r * cols)
            val cx = W / 2 + (c - (inRow - 1) / 2f) * 290f
            val cy = top + r * sp
            val (w, h) = when (level.crush) {
                CrushKind.STAR -> Pair(170f, 170f)
                CrushKind.COOKIE -> Pair(180f, 180f)
                CrushKind.CHALK -> Pair(110f, 190f)
            }
            objs.add(CrushObj(cx, cy, w, h, level.crush, rnd(-0.25f, 0.25f)))
        }
    }

    private fun updateCrunch(dt: Float, f: Float) {
        plateX += (targetX - plateX) * (1f - 0.5f.pow(f))
        plateY += (targetY - plateY) * (1f - 0.55f.pow(f))
        val pressing = crushPtr != -1 && plateY > 0f
        for (o in objs) {
            if (o.crushed) continue
            o.pop = min(1f, o.pop + dt * 3f)
            val top = o.y - o.h / 2
            var press = 0f
            if (pressing && abs(o.x - plateX) < o.w / 2 + 150f) press = ((plateY - top) / (o.h * 0.7f)).coerceIn(0f, 1f)
            o.squash += (press - o.squash) * (1f - 0.5f.pow(f))
            if (press >= 1f) crush(o)
        }
    }

    private fun crush(o: CrushObj) {
        o.crushed = true
        crushed++
        val col = when (o.kind) {
            CrushKind.STAR -> 0xFFFFD83B.toInt()
            CrushKind.COOKIE -> 0xFFC68642.toInt()
            CrushKind.CHALK -> 0xFFF2F2F2.toInt()
        }
        for (i in 0..24) {
            particles.add(Particle(o.x + rnd(-o.w / 3, o.w / 3), o.y + rnd(-o.h / 4, o.h / 4), rnd(-7f, 7f), rnd(-9f, 1f),
                2.2f, 2.2f, rnd(4f, 10f), mix(col, 0xFF5A3A1A.toInt(), Random.nextFloat() * 0.4f), 0.5f, 1, rnd(0f, 6f), rnd(-0.4f, 0.4f), true))
        }
        burst(o.x, o.y, 10, col, 8f, 8f, 0, 0.3f, 0.6f)
        ring(o.x, o.y, col, 130f)
        fb.sound(Snd.CRUNCH, rnd(0.85f, 1.2f)); fb.haptic(true)
        addScore(30); addCoins(1)
        say(o.x, o.y - 70f, "CRUNCH!", col)
        progress = min(level.target, crushed)
        if (progress >= level.target) finish()
    }

    // ================================================================== POUR
    private fun updatePour(dt: Float, f: Float) {
        val tiltActive = abs(tilt) > 0.3f
        tiltS += (tilt - tiltS) * 0.15f
        if (pourPtr == -1 && tiltActive) targetNozX += tilt * 16f * f
        targetNozX = targetNozX.coerceIn(120f, W - 120f)
        nozX += (targetNozX - nozX) * (1f - 0.8f.pow(f))
        val was = pouring
        pouring = (pourPtr != -1 || tiltActive) && !completed
        if (pouring && !was) fb.loopStart(Snd.POUR)
        if (!pouring && was) { fb.loopStop(Snd.POUR); dripLeft = 4f; lastDrop = null }
        if (pouring) {
            emitAcc += f
            hapT -= f
            if (hapT <= 0f) { hapT = 7f; fb.haptic() }
            while (emitAcc >= 1f) {
                emitAcc -= 1f
                val d = Drop(nozX + rnd(-6f, 6f), NOZ_Y + 20f, rnd(-0.3f, 0.3f), 4f, lastDrop)
                drops.add(d); lastDrop = d
            }
        } else if (dripLeft > 0f) {
            dripLeft -= dt; dripT -= dt
            if (dripT <= 0f) { dripT = 0.38f; drops.add(Drop(nozX, NOZ_Y + 22f, 0f, 1.2f, null)) }
        }
        val it = drops.iterator()
        while (it.hasNext()) {
            val d = it.next()
            d.vy = min(d.vy + 0.45f * f, 24f); d.vx *= 0.985f.pow(f)
            d.x += d.vx * f; d.y += d.vy * f
            var dead = false
            if (d.x > JX0 + 6f && d.x < JX1 - 6f) {
                val col = ((d.x - JX0) / 20f).toInt().coerceIn(0, JC - 1)
                if (d.y >= JB - jarH[col]) {
                    jarH[col] = min(JCAP + 20f, jarH[col] + 9f)
                    if (col > 0) jarH[col - 1] += 4f
                    if (col < JC - 1) jarH[col + 1] += 4f
                    dead = true
                }
            } else if (d.y > JT && d.y < JB && ((d.x > JX0 - 16f && d.x <= JX0 + 6f) || (d.x >= JX1 - 6f && d.x < JX1 + 16f))) {
                d.x = if (d.x < W / 2) JX0 - 18f else JX1 + 18f; d.vx = if (d.x < W / 2) -1f else 1f
            }
            val sc = (d.x / 20f).toInt().coerceIn(0, 53)
            if (!dead && d.y >= JB - spill[sc] && !(d.x > JX0 - 16f && d.x < JX1 + 16f && d.y > JT)) {
                spill[sc] = min(34f, spill[sc] + 5f)
                if (sc > 0) spill[sc - 1] = min(34f, spill[sc - 1] + 2f)
                if (sc < 53) spill[sc + 1] = min(34f, spill[sc + 1] + 2f)
                dead = true
            }
            if (dead) { d.alive = false; it.remove() }
        }
        // viscous relaxation
        for (i in 0 until JC) {
            val l = if (i > 0) jarH[i - 1] else jarH[i]
            val r = if (i < JC - 1) jarH[i + 1] else jarH[i]
            jarH[i] += ((l + r) * 0.5f - jarH[i]) * 0.12f * f
            jarH[i] = min(jarH[i], JCAP + 20f)
        }
        var sum = 0f
        for (h in jarH) sum += h
        val pct = (sum / (JC * JCAP) * 100f).toInt().coerceIn(0, 100)
        if (pct != progress) progress = pct
        if (!completed && pct >= level.target) { fb.loopStop(Snd.POUR); finish() }
    }

    // ================================================================== RENDER
    private val WHITE = 0xFFFFFFFF.toInt()

    private fun fillP(color: Int) { paint.style = Paint.Style.FILL; paint.shader = null; paint.color = color }
    private fun strokeP(color: Int, w: Float) {
        paint.style = Paint.Style.STROKE; paint.shader = null; paint.color = color
        paint.strokeWidth = w; paint.strokeCap = Paint.Cap.ROUND; paint.strokeJoin = Paint.Join.ROUND
    }
    private fun glowCircle(c: Canvas, x: Float, y: Float, r: Float, color: Int, a: Float = 1f) {
        fillP(alpha(color, 0.10f * a))
        for (i in 3 downTo 1) c.drawCircle(x, y, r * (1f + i * 0.7f), paint)
        fillP(alpha(color, a)); c.drawCircle(x, y, r, paint)
    }
    private fun glowLine(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, color: Int, a: Float = 1f) {
        for (i in 3 downTo 1) { strokeP(alpha(color, 0.10f * a), w * (1f + i * 1.1f)); c.drawLine(x1, y1, x2, y2, paint) }
        strokeP(alpha(color, a), w); c.drawLine(x1, y1, x2, y2, paint)
        strokeP(alpha(WHITE, a * 0.9f), w * 0.35f); c.drawLine(x1, y1, x2, y2, paint)
    }
    private fun glowPath(c: Canvas, color: Int, w: Float, a: Float = 1f) {
        for (i in 3 downTo 1) { strokeP(alpha(color, 0.09f * a), w * (1f + i * 0.9f)); c.drawPath(path, paint) }
        strokeP(alpha(color, a), w); c.drawPath(path, paint)
    }
    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, a: Float = 1f) {
        textPaint.textSize = size
        textPaint.style = Paint.Style.STROKE; textPaint.strokeWidth = size * 0.18f; textPaint.color = alpha(color, 0.3f * a)
        c.drawText(s, x, y, textPaint)
        textPaint.style = Paint.Style.FILL; textPaint.color = alpha(color, a)
        c.drawText(s, x, y, textPaint)
    }

    fun render(c: Canvas, w: Float, h: Float) {
        drawBackground(c)
        when (level.type) {
            LevelType.SLICE -> drawSlice(c)
            LevelType.SQUISH -> drawSquish(c)
            LevelType.TAP -> drawTap(c)
            LevelType.CRUNCH -> drawCrunch(c)
            LevelType.POUR -> drawPour(c)
        }
        // particles
        for (p in particles) {
            val t = (p.life / p.maxLife).coerceIn(0f, 1f)
            when (p.kind) {
                0 -> glowCircle(c, p.x, p.y, p.size * t + 1f, p.color, t)
                1 -> { fillP(alpha(p.color, min(1f, t * 2f))); c.save(); c.rotate(p.rot * DEG, p.x, p.y)
                    c.drawRect(p.x - p.size / 2, p.y - p.size / 2, p.x + p.size / 2, p.y + p.size / 2, paint); c.restore() }
                2 -> { strokeP(alpha(p.color, t), 6f * t + 1f); c.drawCircle(p.x, p.y, p.size * (1f - t) + 6f, paint) }
                3 -> { fillP(alpha(p.color, min(1f, t * 2f) * 0.85f)); c.save(); c.rotate(p.rot * DEG, p.x, p.y)
                    path.reset(); path.moveTo(p.x, p.y - p.size); path.lineTo(p.x + p.size * 0.6f, p.y + p.size * 0.5f)
                    path.lineTo(p.x - p.size * 0.6f, p.y + p.size * 0.5f); path.close(); c.drawPath(path, paint); c.restore() }
                else -> { fillP(alpha(p.color, min(1f, t * 2f))); c.drawCircle(p.x, p.y, p.size, paint) }
            }
        }
        // slash flashes + trail
        for (fl in flashes) glowLine(c, fl.x1, fl.y1, fl.x2, fl.y2, 6f + fl.life * 40f, fl.color, (fl.life / 0.22f).coerceIn(0f, 1f))
        if (level.type == LevelType.SLICE) {
            for (i in 1 until trail.size) {
                val a = trail[i - 1]; val b = trail[i]
                val t = (1f - b.age / 0.28f).coerceIn(0f, 1f)
                if (hypot(b.x - a.x, b.y - a.y) < 220f) glowLine(c, a.x, a.y, b.x, b.y, knife.width * t, knife.color, t)
            }
        }
        if (level.type == LevelType.SLICE && s3d == null) drawHand(c)
        for (t in texts) text(c, t.text, t.x, t.y, 64f * t.scale, t.color, min(1f, t.life * 2f))
    }

    private fun drawBackground(c: Canvas) {
        var sh = bgShader
        if (sh == null) {
            sh = LinearGradient(0f, 0f, 0f, H, intArrayOf(0xFF07060F.toInt(), 0xFF1A1040.toInt(), 0xFF0B0820.toInt()), null, Shader.TileMode.CLAMP)
            bgShader = sh
        }
        paint.style = Paint.Style.FILL; paint.shader = sh; c.drawRect(0f, 0f, W, H, paint); paint.shader = null
        val cols = intArrayOf(0xFF8A4DFF.toInt(), 0xFFFF2E9A.toInt(), 0xFF22F0FF.toInt())
        for (i in 0 until 12) {
            val x = (i * 211f) % W + sin(time * 0.4f + i) * 40f
            val y = (i * 397f) % H + cos(time * 0.3f + i * 2f) * 50f
            fillP(alpha(cols[i % 3], 0.06f)); c.drawCircle(x, y, 70f + (i % 4) * 35f, paint)
        }
    }

    // ---------------------------------------------------------------- slice drawing
    private fun drawSlice(c: Canvas) {
        s3d?.let { it.render(c); return }
        val sh = LinearGradient(0f, FLOOR, 0f, H, 0xFF1B1245.toInt(), 0xFF07060F.toInt(), Shader.TileMode.CLAMP)
        paint.style = Paint.Style.FILL; paint.shader = sh; c.drawRect(0f, FLOOR, W, H, paint); paint.shader = null
        glowLine(c, 0f, FLOOR, W, FLOOR, 4f, 0xFF22F0FF.toInt(), 0.8f)
        for (s in strands) {
            val a = (s.life / 0.55f).coerceIn(0f, 1f)
            strokeP(alpha(s.color, a * 0.8f), 10f * a + 1f)
            c.drawLine(s.a.cx, s.a.cy, s.b.cx, s.b.cy, paint)
        }
        for (pc in pieces) drawPiece(c, pc)
    }

    private fun drawPiece(c: Canvas, pc: Piece) {
        val a = pc.fade.coerceIn(0f, 1f)
        val n = pc.local.size
        val cs = cos(pc.angle); val sn = sin(pc.angle)
        val wob = if (pc.mat == Material.JELLY || pc.mat == Material.CLAY) pc.wobble else 0f
        val depth = 42f
        val xs = FloatArray(n); val ys = FloatArray(n)
        for (i in 0 until n) {
            var lx = pc.local[i].x; var ly = pc.local[i].y
            if (wob > 0.02f) {
                val l = max(1f, hypot(lx, ly)); val j = sin(time * 22f + i * 1.7f) * wob * 9f
                lx += lx / l * j; ly += ly / l * j
            }
            xs[i] = pc.cx + lx * cs - ly * sn
            ys[i] = pc.cy + lx * sn + ly * cs - depth
        }
        val m = pc.mat
        val black = 0xFF000000.toInt()

        // soft floor shadow
        val air = (FLOOR - (pc.cy + pc.lowest())).coerceIn(0f, 700f)
        fillP(alpha(black, 0.35f * a * (1f - air / 800f)))
        val sw = pc.radius * 1.05f * (1f + air / 900f)
        rect.set(pc.cx - sw, FLOOR - 6f, pc.cx + sw, FLOOR + 24f)
        c.drawOval(rect, paint)

        // extruded side walls (gives the 3D thickness)
        for (i in 0 until n) {
            val j = (i + 1) % n
            val ex = xs[j] - xs[i]; val ey = ys[j] - ys[i]
            var nx = ey; var ny = -ex
            val mx = (xs[i] + xs[j]) / 2f - pc.cx
            val my = (ys[i] + ys[j]) / 2f + depth - pc.cy
            if (nx * mx + ny * my < 0f) { nx = -nx; ny = -ny }
            val nl = max(1f, hypot(nx, ny)); nx /= nl; ny /= nl
            if (ny < -0.15f) continue
            val shade = (0.55f - nx * 0.35f + ny * 0.25f).coerceIn(0.15f, 0.9f)
            path.reset()
            path.moveTo(xs[i], ys[i]); path.lineTo(xs[j], ys[j])
            path.lineTo(xs[j], ys[j] + depth); path.lineTo(xs[i], ys[i] + depth); path.close()
            val col = alpha(mix(m.bottom, black, shade * 0.75f), a)
            fillP(col); c.drawPath(path, paint)
            strokeP(col, 1.5f); c.drawPath(path, paint)
        }

        // top face
        fun topPath() {
            path.reset()
            for (i in 0 until n) { if (i == 0) path.moveTo(xs[i], ys[i]) else path.lineTo(xs[i], ys[i]) }
            path.close()
        }
        topPath()
        for (k in 3 downTo 1) { strokeP(alpha(m.accent, 0.07f * a), 8f + k * 8f); c.drawPath(path, paint) }
        val ty = pc.cy - depth
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(pc.cx, ty - pc.radius, pc.cx, ty + pc.radius, alpha(m.top, a), alpha(m.bottom, a), Shader.TileMode.CLAMP)
        c.drawPath(path, paint); paint.shader = null

        // texture + specular
        c.save()
        c.clipPath(path)
        c.translate(pc.cx, ty); c.rotate(pc.angle * DEG)
        val d = pc.tex.dots
        val r2 = (pc.radius + 20f) * (pc.radius + 20f)
        when (m) {
            Material.SOAP, Material.CLAY, Material.SAND, Material.JELLY -> {
                for (i in 0 until 110) {
                    val x = d[i * 3] - pc.texOff.x; val y = d[i * 3 + 1] - pc.texOff.y
                    if (x * x + y * y > r2) continue
                    val r = d[i * 3 + 2]
                    when (m) {
                        Material.SAND -> { fillP(alpha(if (i % 2 == 0) 0xFF7A5A2A.toInt() else m.accent, 0.55f * a)); c.drawCircle(x, y, r * 0.4f, paint) }
                        Material.SOAP -> { fillP(alpha(WHITE, 0.22f * a)); c.drawCircle(x, y, r * 0.6f, paint) }
                        Material.JELLY -> { strokeP(alpha(WHITE, 0.3f * a), 2f); c.drawCircle(x, y, r * 1.4f, paint) }
                        else -> { fillP(alpha(0xFF1B3A9A.toInt(), 0.22f * a)); c.drawCircle(x, y, r * 1.1f, paint) }
                    }
                }
            }
            Material.CRYSTAL -> {
                strokeP(alpha(WHITE, 0.35f * a), 2.5f)
                for (i in 0 until n step 2) c.drawLine(0f, 0f, pc.local[i].x, pc.local[i].y, paint)
                fillP(alpha(WHITE, 0.14f * a))
                for (i in 0 until n step 4) {
                    val p = pc.local[i]; val q = pc.local[(i + 1) % n]
                    path.reset(); path.moveTo(0f, 0f); path.lineTo(p.x, p.y); path.lineTo(q.x, q.y); path.close()
                    c.drawPath(path, paint)
                }
            }
            Material.WOOD -> {
                strokeP(alpha(0xFF4A2A0A.toInt(), 0.28f * a), 4f)
                for (k in 1..12) c.drawCircle(-pc.texOff.x - 380f, -pc.texOff.y, k * 48f, paint)
                strokeP(alpha(0xFFFFE0B0.toInt(), 0.15f * a), 2f)
                for (k in 0 until 6) c.drawLine(-400f, -pc.texOff.y - 140f + k * 55f, 400f, -pc.texOff.y - 130f + k * 55f, paint)
            }
        }
        // glossy light from upper-left
        fillP(alpha(WHITE, 0.12f * a))
        rect.set(-pc.radius, -pc.radius, pc.radius * 0.25f, -pc.radius * 0.05f)
        c.drawOval(rect, paint)
        strokeP(alpha(WHITE, 0.45f * a), 12f)
        c.drawLine(-pc.radius * 0.6f, -pc.radius * 0.55f, -pc.radius * 0.15f, -pc.radius * 0.7f, paint)
        c.restore()

        topPath()
        strokeP(alpha(WHITE, 0.6f * a), 3f); c.drawPath(path, paint)
    }

    // ---------------------------------------------------------------- hand + knife
    private fun rr(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float) {
        rect.set(l, t, r, b); c.drawRoundRect(rect, rad, rad, paint)
    }
    private fun skinFill(top: Float, bottom: Float) {
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, top, 0f, bottom, 0xFFF3CBA9.toInt(), 0xFFC98F6B.toInt(), Shader.TileMode.CLAMP)
    }

    /** Local space: knife tip at origin, +x runs from the tip back toward the hand/forearm. */
    private fun drawHand(c: Canvas) {
        if (handA < 0.03f) return
        c.saveLayerAlpha(null, (handA.coerceIn(0f, 1f) * 255f).toInt())
        c.translate(handX, handY)
        c.rotate(handAng * DEG)
        c.scale(0.78f, 0.78f)
        val black = 0xFF000000.toInt()
        // shadow
        fillP(alpha(black, 0.22f)); rr(c, 10f, 44f, 480f, 80f, 20f)
        // blade
        path.reset()
        path.moveTo(0f, 4f); path.quadTo(30f, -26f, 90f, -30f); path.lineTo(300f, -30f); path.lineTo(300f, 28f)
        path.lineTo(110f, 28f); path.quadTo(30f, 26f, 0f, 4f); path.close()
        strokeP(alpha(knife.color, 0.35f), 16f); c.drawPath(path, paint)
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, -30f, 0f, 28f,
            intArrayOf(0xFFF6F8FF.toInt(), 0xFFA9B2C8.toInt(), 0xFFE8ECF6.toInt(), 0xFF7F889E.toInt()),
            floatArrayOf(0f, 0.45f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawPath(path, paint); paint.shader = null
        strokeP(alpha(WHITE, 0.9f), 3f); c.drawLine(110f, 27f, 300f, 27f, paint)
        strokeP(alpha(black, 0.18f), 3f); c.drawLine(70f, -2f, 300f, -2f, paint)
        // bolster + handle
        fillP(0xFFB8BFD0.toInt()); rr(c, 296f, -36f, 312f, 30f, 6f)
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, -34f, 0f, 28f, 0xFF5A3A24.toInt(), 0xFF21120A.toInt(), Shader.TileMode.CLAMP)
        rr(c, 310f, -34f, 480f, 28f, 16f); paint.shader = null
        fillP(0xFFD9B35A.toInt())
        for (k in 0..2) c.drawCircle(340f + k * 52f, -3f, 6f, paint)
        // palm + forearm
        skinFill(-60f, 60f); rr(c, 440f, -56f, 610f, 58f, 40f)
        skinFill(-62f, 58f); rr(c, 590f, -52f, 1100f, 50f, 44f)
        paint.shader = null
        fillP(0xFF22224A.toInt()); rr(c, 860f, -78f, 1120f, 76f, 24f)
        fillP(0xFFFF2E9A.toInt()); rr(c, 860f, -78f, 876f, 76f, 6f)
        // four fingers wrapped around the handle (edge side)
        for (i in 0..3) {
            val x = 318f + i * 40f
            val bot = 56f - i * 3f
            skinFill(-10f, 56f); rr(c, x, -12f, x + 38f, bot, 19f); paint.shader = null
            strokeP(alpha(0xFF8F5B3C.toInt(), 0.55f), 2f); rect.set(x, -12f, x + 38f, bot); c.drawRoundRect(rect, 19f, 19f, paint)
            fillP(alpha(WHITE, 0.25f)); rect.set(x + 6f, -4f, x + 22f, 8f); c.drawOval(rect, paint)
        }
        // thumb resting on the spine
        c.save(); c.translate(372f, -32f); c.rotate(-16f)
        skinFill(-18f, 18f); rr(c, 0f, -18f, 130f, 18f, 18f); paint.shader = null
        fillP(alpha(0xFFFFE6D2.toInt(), 0.9f)); rr(c, 8f, -12f, 38f, 2f, 8f)
        c.restore()
        c.restore()
    }

    // ---------------------------------------------------------------- squish drawing
    private fun drawSquish(c: Canvas) {
        var cx = 0f; var cy = 0f
        for (i in 0 until bn) { cx += bx[i]; cy += by[i] }
        cx /= bn; cy /= bn
        val m = level.material
        path.reset()
        path.moveTo((bx[bn - 1] + bx[0]) / 2, (by[bn - 1] + by[0]) / 2)
        for (i in 0 until bn) {
            val n = (i + 1) % bn
            path.quadTo(bx[i], by[i], (bx[i] + bx[n]) / 2, (by[i] + by[n]) / 2)
        }
        path.close()
        glowPath(c, 0xFFB6FF3B.toInt(), 8f, 0.6f)
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx - 90f, cy - 110f, 440f, m.top, m.bottom, Shader.TileMode.CLAMP)
        c.drawPath(path, paint); paint.shader = null
        c.save(); c.clipPath(path)
        fillP(alpha(WHITE, 0.2f)); rect.set(cx - 210f, cy - 220f, cx + 40f, cy - 100f); c.drawOval(rect, paint)
        fillP(alpha(WHITE, 0.10f))
        for (i in 0 until 9) c.drawCircle(cx + sin(i * 2.3f) * 200f, cy + cos(i * 1.7f) * 150f, 10f + (i % 3) * 8f, paint)
        c.restore()
        strokeP(alpha(WHITE, 0.55f), 4f); c.drawPath(path, paint)
        val gs = grabs.values.toList()
        for (g in gs) glowCircle(c, g.cx, g.cy, 22f, 0xFFB6FF3B.toInt(), 0.9f)
        if (gs.size >= 2) glowLine(c, gs[0].cx, gs[0].cy, gs[1].cx, gs[1].cy, 4f, 0xFFFF2E9A.toInt(), 0.7f)
    }

    // ---------------------------------------------------------------- tap drawing
    private fun drawTap(c: Canvas) {
        rect.set(surface)
        path.reset(); path.addRoundRect(rect, 70f, 70f, Path.Direction.CW)
        glowPath(c, 0xFFFF2E9A.toInt(), 8f, 0.8f)
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, surface.top, 0f, surface.bottom, 0xFF2E2268.toInt(), 0xFF140E33.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, paint); paint.shader = null
        c.save(); c.clipPath(path)
        fillP(alpha(WHITE, 0.05f))
        var yy = surface.top + 30f
        while (yy < surface.bottom) { var xx = surface.left + 30f; while (xx < surface.right) { c.drawCircle(xx, yy, 3f, paint); xx += 60f }; yy += 60f }
        for (s in segs) {
            strokeP(alpha(0xFF000000.toInt(), 0.5f), 7f); c.drawLine(s.x1, s.y1, s.x2, s.y2, paint)
            strokeP(alpha(WHITE, 0.75f), 2.5f); c.drawLine(s.x1 + 1.5f, s.y1 + 1.5f, s.x2 + 1.5f, s.y2 + 1.5f, paint)
        }
        for (r in ripples) {
            val t = r.age / 1.1f
            for (k in 0..2) {
                val rad = t * 300f - k * 45f
                if (rad > 0f) { strokeP(alpha(if (k == 0) 0xFFFF2E9A.toInt() else WHITE, (1f - t) * 0.8f), 6f * (1f - t) + 1f); c.drawCircle(r.x, r.y, rad, paint) }
            }
        }
        c.restore()
        strokeP(alpha(WHITE, 0.4f), 3f); c.drawPath(path, paint)
    }

    // ---------------------------------------------------------------- crunch drawing
    private fun starPath(x: Float, y: Float, R: Float) {
        path.reset()
        for (i in 0 until 10) {
            val a = -PI_F / 2f + i * PI_F / 5f
            val r = if (i % 2 == 0) R else R * 0.45f
            if (i == 0) path.moveTo(x + cos(a) * r, y + sin(a) * r) else path.lineTo(x + cos(a) * r, y + sin(a) * r)
        }
        path.close()
    }

    private fun drawCrunch(c: Canvas) {
        glowLine(c, 0f, floorY, W, floorY, 4f, 0xFFFFD83B.toInt(), 0.7f)
        for ((idx, o) in objs.withIndex()) {
            if (o.crushed) continue
            val s = o.pop
            c.save()
            c.translate(o.x, o.y + o.squash * o.h * 0.25f)
            c.rotate(o.rot * DEG)
            c.scale((1f + 0.25f * o.squash) * s, (1f - 0.5f * o.squash) * s)
            when (o.kind) {
                CrushKind.STAR -> {
                    starPath(0f, 0f, o.w / 2f)
                    glowPath(c, 0xFFFFD83B.toInt(), 8f, 0.6f)
                    fillP(0xFFFFE45C.toInt()); c.drawPath(path, paint)
                    strokeP(alpha(WHITE, 0.8f), 4f); c.drawPath(path, paint)
                    fillP(alpha(WHITE, 0.5f)); c.drawCircle(-18f, -22f, 12f, paint)
                }
                CrushKind.COOKIE -> {
                    glowCircle(c, 0f, 0f, o.w / 2f, 0xFFFF9A3B.toInt(), 0.35f)
                    paint.style = Paint.Style.FILL
                    paint.shader = RadialGradient(-20f, -25f, o.w * 0.7f, 0xFFE6A85C.toInt(), 0xFF9A5A22.toInt(), Shader.TileMode.CLAMP)
                    c.drawCircle(0f, 0f, o.w / 2f, paint); paint.shader = null
                    fillP(0xFF3A1E0C.toInt())
                    for (k in 0 until 7) c.drawCircle(cos(k * 2.1f + idx) * o.w * 0.28f, sin(k * 2.9f + idx) * o.w * 0.28f, 9f + (k % 3) * 3f, paint)
                    strokeP(alpha(WHITE, 0.4f), 3f); c.drawCircle(0f, 0f, o.w / 2f, paint)
                }
                CrushKind.CHALK -> {
                    rect.set(-o.w / 2, -o.h / 2, o.w / 2, o.h / 2)
                    val tint = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFC9E8.toInt(), 0xFFC9F4FF.toInt(), 0xFFFFF3B0.toInt())[idx % 4]
                    path.reset(); path.addRoundRect(rect, 18f, 18f, Path.Direction.CW)
                    glowPath(c, tint, 6f, 0.5f)
                    fillP(tint); c.drawPath(path, paint)
                    strokeP(alpha(0xFF000000.toInt(), 0.12f), 3f)
                    for (k in 1..4) c.drawLine(-o.w / 2 + 8f, -o.h / 2 + k * o.h / 5f, o.w / 2 - 8f, -o.h / 2 + k * o.h / 5f, paint)
                }
            }
            c.restore()
        }
        if (plateY > -120f) {
            val pl = plateX - 170f; val pr = plateX + 170f
            fillP(0xFF4A4F8F.toInt()); c.drawRect(plateX - 34f, -20f, plateX + 34f, plateY - 50f, paint)
            rect.set(pl, plateY - 70f, pr, plateY)
            path.reset(); path.addRoundRect(rect, 26f, 26f, Path.Direction.CW)
            glowPath(c, 0xFF22F0FF.toInt(), 6f, 0.9f)
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(0f, plateY - 70f, 0f, plateY, 0xFFD6DBFF.toInt(), 0xFF6A70B8.toInt(), Shader.TileMode.CLAMP)
            c.drawPath(path, paint); paint.shader = null
        }
    }

    // ---------------------------------------------------------------- pour drawing
    private fun drawPour(c: Canvas) {
        // table
        fillP(0xFF120C2B.toInt()); c.drawRect(0f, JB, W, H, paint)
        glowLine(c, 0f, JB, W, JB, 4f, 0xFFFF9A3B.toInt(), 0.7f)
        // spill puddle
        path.reset(); path.moveTo(0f, JB)
        for (i in 0 until 54) path.lineTo(i * 20f + 10f, JB - spill[i])
        path.lineTo(W, JB); path.close()
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, JB - 34f, 0f, JB, fluidTop, fluidBot, Shader.TileMode.CLAMP)
        c.drawPath(path, paint); paint.shader = null
        // jar liquid
        var sum = 0f
        for (h in jarH) sum += h
        if (sum > 1f) {
            path.reset(); path.moveTo(JX0, JB)
            for (i in 0 until JC) path.lineTo(JX0 + i * 20f + 10f, JB - jarH[i])
            path.lineTo(JX1, JB); path.close()
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(0f, JB - JCAP, 0f, JB, fluidTop, fluidBot, Shader.TileMode.CLAMP)
            c.drawPath(path, paint); paint.shader = null
            path.reset()
            for (i in 0 until JC) { val x = JX0 + i * 20f + 10f; val y = JB - jarH[i]; if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
            strokeP(alpha(WHITE, 0.6f), 4f); c.drawPath(path, paint)
        }
        // jar glass
        path.reset(); path.moveTo(JX0 - 10f, JT); path.lineTo(JX0 - 10f, JB); path.lineTo(JX1 + 10f, JB); path.lineTo(JX1 + 10f, JT)
        glowPath(c, 0xFF22F0FF.toInt(), 6f, 0.7f)
        val gy = JB - level.target / 100f * JCAP
        strokeP(alpha(0xFFFFD83B.toInt(), 0.9f), 4f); c.drawLine(JX0 - 24f, gy, JX1 + 24f, gy, paint)
        text(c, "${level.target}%", JX1 + 80f, gy + 12f, 34f, 0xFFFFD83B.toInt(), 0.9f)
        // drops
        for (d in drops) {
            val pv = d.prev
            if (pv != null && pv.alive && hypot(pv.x - d.x, pv.y - d.y) < 90f) {
                strokeP(fluidTop, 14f); c.drawLine(pv.x, pv.y, d.x, d.y, paint)
                strokeP(alpha(WHITE, 0.35f), 4f); c.drawLine(pv.x - 3f, pv.y, d.x - 3f, d.y, paint)
            }
        }
        for (d in drops) { fillP(fluidTop); c.drawCircle(d.x, d.y, 8f, paint); fillP(alpha(WHITE, 0.5f)); c.drawCircle(d.x - 2f, d.y - 2f, 3f, paint) }
        // bottle
        c.save()
        c.translate(nozX, NOZ_Y)
        c.rotate((tiltS * 28f).coerceIn(-25f, 25f))
        rect.set(-110f, -300f, 110f, -70f)
        path.reset(); path.addRoundRect(rect, 44f, 44f, Path.Direction.CW)
        glowPath(c, 0xFFFF9A3B.toInt(), 6f, 0.6f)
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(-110f, 0f, 110f, 0f, alpha(fluidTop, 0.9f), alpha(fluidBot, 0.95f), Shader.TileMode.CLAMP)
        c.drawPath(path, paint)
        path.reset(); path.moveTo(-110f, -90f); path.lineTo(110f, -90f); path.lineTo(32f, 0f); path.lineTo(-32f, 0f); path.close()
        c.drawPath(path, paint); paint.shader = null
        fillP(0xFFEDEDFF.toInt()); rect.set(-30f, 0f, 30f, 24f); c.drawRoundRect(rect, 8f, 8f, paint)
        fillP(alpha(WHITE, 0.35f)); rect.set(-80f, -270f, -50f, -110f); c.drawRoundRect(rect, 14f, 14f, paint)
        c.restore()
    }
}

// ====================================================================== Compose host
@Composable
fun GameCanvasView(world: GameWorld, recorder: GameRecorderManager, modifier: Modifier = Modifier) {
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(world) {
        var lastNs = 0L
        while (true) {
            withFrameNanosCompat { now ->
                val dt = if (lastNs == 0L) 1f / 60f else ((now - lastNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                lastNs = now
                world.update(dt)
                recorder.captureFrame(world)
                tick = now
            }
        }
    }
    ComposeCanvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(world) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent()
                        val s = min(size.width / GameWorld.W, size.height / GameWorld.H)
                        val ox = (size.width - GameWorld.W * s) / 2f
                        val oy = (size.height - GameWorld.H * s) / 2f
                        for (ch in ev.changes) {
                            val x = (ch.position.x - ox) / s
                            val y = (ch.position.y - oy) / s
                            val id = ch.id.value.toInt()
                            if (ch.changedToDown()) world.pointerDown(id, x, y)
                            else if (ch.changedToUp()) world.pointerUp(id, x, y)
                            else if (ch.pressed && ch.positionChanged()) world.pointerMove(id, x, y)
                            ch.consume()
                        }
                    }
                }
            }
    ) {
        @Suppress("UNUSED_VARIABLE") val t = tick
        val s = min(size.width / GameWorld.W, size.height / GameWorld.H)
        val ox = (size.width - GameWorld.W * s) / 2f
        val oy = (size.height - GameWorld.H * s) / 2f
        drawIntoCanvas { cv ->
            val nc = cv.nativeCanvas
            nc.save()
            nc.translate(ox, oy)
            nc.scale(s, s)
            nc.clipRect(0f, 0f, GameWorld.W, GameWorld.H)
            world.render(nc, GameWorld.W, GameWorld.H)
            nc.restore()
        }
    }
}

private suspend fun withFrameNanosCompat(block: (Long) -> Unit) {
    androidx.compose.runtime.withFrameNanos { block(it) }
}

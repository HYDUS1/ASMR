package com.satisfying.slicegame.asmr

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun GameScreen(
    level: Int, store: GameStore, sound: SoundManager, recorder: GameRecorderManager,
    onBack: () -> Unit, onNext: () -> Unit, onMap: () -> Unit
) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val def = LevelManager.get(level)
    val scope = rememberCoroutineScope()
    var attempt by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }
    var recSec by remember { mutableIntStateOf(0) }

    SideEffect { sound.view = view }

    val fb = remember(sound) {
        object : Feedback {
            override fun sound(s: Snd, rate: Float, vol: Float) = sound.play(s, rate, vol)
            override fun haptic(strong: Boolean) = sound.haptic(strong)
            override fun loopStart(s: Snd) = sound.startLoop(s)
            override fun loopStop(s: Snd) = sound.stopLoop(s)
        }
    }
    val world = remember(level, attempt) { GameWorld(def, fb, store) }

    LaunchedEffect(store.knife, world) { world.knife = Knife.values()[store.knife.coerceIn(0, 3)] }

    // tilt for POUR levels
    DisposableEffect(world) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val acc = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) { world.tilt = (-e.values[0] / 9.81f).coerceIn(-1f, 1f) }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (def.type == LevelType.POUR && acc != null) sm.registerListener(l, acc, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm?.unregisterListener(l); sound.stopAllLoops() }
    }

    // stop recording if the player leaves the screen
    DisposableEffect(Unit) {
        onDispose { if (recorder.isRecording) Thread { recorder.stop() }.start() }
    }

    LaunchedEffect(world.showWin) { if (world.showWin) store.completeLevel(level, world.stars) }

    LaunchedEffect(recorder.isRecording) {
        while (recorder.isRecording) {
            recSec = ((System.currentTimeMillis() - recorder.startedAtMs) / 1000).toInt()
            delay(250)
        }
    }
    LaunchedEffect(toast) { if (toast != null) { delay(3200); toast = null } }

    fun startRec(mic: Boolean) {
        if (!recorder.start(mic)) toast = "Recording isn't supported on this device"
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> startRec(granted) }

    fun onRecClick() {
        if (recorder.isRecording) {
            scope.launch {
                val uri = withContext(Dispatchers.IO) { recorder.stop() }
                toast = if (uri == null) "Could not save the recording"
                else if (Build.VERSION.SDK_INT >= 29) "Gameplay saved to Gallery (Movies/SliceGame)"
                else "Gameplay saved to the app's Movies folder"
            }
        } else {
            val has = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (store.micAudio && !has) permLauncher.launch(Manifest.permission.RECORD_AUDIO)
            else startRec(store.micAudio && has)
        }
    }

    BackHandler { if (showSettings) showSettings = false else onBack() }

    Box(Modifier.fillMaxSize().background(Neon.bgBrush)) {
        Column(Modifier.fillMaxSize()) {
            // ---------------- top bar
            Row(
                Modifier.statusBarsPadding().fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Chip("LV $level", Color(def.tint))
                Chip("SCORE ${world.score}", Neon.Cyan)
                Chip("● ${store.coins}", Neon.Yellow)
                Spacer(Modifier.weight(1f))
                Box(Modifier.neonGlow(Neon.Cyan, 20.dp, 8.dp).clip(CircleShape).background(Neon.Panel)
                    .clickable { showSettings = true }.padding(8.dp)) {
                    Icon(Icons.Filled.Settings, "Settings", tint = Neon.Cyan, modifier = Modifier.size(22.dp))
                }
                if (recorder.isRecording) {
                    val blink = (System.currentTimeMillis() / 500) % 2L == 0L
                    Row(Modifier.neonGlow(Color.Red, 18.dp, 8.dp).clip(RoundedCornerShape(18.dp)).background(Neon.Panel)
                        .clickable { onRecClick() }.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(if (blink || true) Color.Red else Color.Transparent))
                        Spacer(Modifier.width(6.dp))
                        Text("REC %02d:%02d".format(recSec / 60, recSec % 60), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Box(Modifier.neonGlow(Neon.Pink, 20.dp, 8.dp).clip(CircleShape).background(Neon.Panel)
                        .clickable { onRecClick() }.padding(8.dp)) { CameraIcon(Neon.Pink) }
                }
            }
            // ---------------- goal
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Text(def.goalText.uppercase(), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                val frac = (world.progress.toFloat() / def.target).coerceIn(0f, 1f)
                Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2A2250))) {
                    Box(Modifier.fillMaxWidth(frac).height(8.dp).background(Color(def.tint)))
                }
            }
            // ---------------- canvas
            Box(Modifier.weight(1f).fillMaxWidth()) {
                GameCanvasView(world, recorder)
            }
            // ---------------- bottom
            Column(Modifier.navigationBarsPadding().fillMaxWidth().padding(10.dp)) {
                if (def.type == LevelType.SLICE) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (i in 0 until 4) {
                            val k = Knife.values()[i]
                            val owned = store.knifeOwned(i)
                            val sel = store.knife == i
                            val col = Color(k.color)
                            Column(
                                Modifier.weight(1f).neonGlow(if (sel) col else Color(0xFF3A3560), 14.dp, if (sel) 10.dp else 3.dp)
                                    .clip(RoundedCornerShape(14.dp)).background(Neon.Panel)
                                    .clickable {
                                        if (!store.chooseKnife(i)) toast = "Need ${k.cost} coins for ${k.title}"
                                        else world.knife = Knife.values()[i]
                                    }.padding(vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(Modifier.width(34.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(col))
                                Spacer(Modifier.height(4.dp))
                                Text(k.title, color = col, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(if (owned) (if (sel) "EQUIPPED" else "OWNED") else "● ${k.cost}", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                            }
                        }
                    }
                } else {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Chip(def.type.hint, Color(def.tint)) }
                }
            }
        }

        toast?.let {
            Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = 110.dp), contentAlignment = Alignment.TopCenter) { Chip(it, Neon.Lime) }
        }

        if (world.showWin) {
            Box(Modifier.fillMaxSize().background(Color(0xDD07060F)), contentAlignment = Alignment.Center) {
                Column(
                    Modifier.padding(28.dp).neonGlow(Neon.Yellow, 28.dp).clip(RoundedCornerShape(28.dp))
                        .background(Color(0xFF14102B)).padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    GlowText("LEVEL CLEAR!", Neon.Yellow, 30)
                    Spacer(Modifier.height(8.dp))
                    Text("★".repeat(world.stars) + "☆".repeat(3 - world.stars), color = Neon.Yellow, fontSize = 40.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Score ${world.score}   Coins +${world.coins}", color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(20.dp))
                    if (level < LevelManager.COUNT) NeonButton("NEXT", Neon.Lime, onNext)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        NeonButton("REPLAY", Neon.Cyan, { attempt++ }, size = 15)
                        NeonButton("MAP", Neon.Pink, onMap, size = 15)
                    }
                }
            }
        }
        if (showSettings) SettingsPanel(store) { showSettings = false }
    }
}

package com.satisfying.slicegame.asmr

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { SliceApp() }
    }
}

@Composable
fun SliceApp() {
    val ctx = LocalContext.current.applicationContext
    val store = remember { GameStore(ctx) }
    val sound = remember { SoundManager(ctx) }
    val recorder = remember { GameRecorderManager(ctx) }
    SideEffect { sound.soundOn = store.soundOn; sound.hapticOn = store.hapticOn }
    DisposableEffect(Unit) { onDispose { sound.release() } }

    val nav = rememberNavController()
    var showSettings by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        NavHost(nav, startDestination = "start") {
            composable("start") {
                StartScreen(store, onPlay = { nav.navigate("map") }, onSettings = { showSettings = true })
            }
            composable("map") {
                LevelMapScreen(store, onBack = { nav.popBackStack() }, onLevel = { n -> nav.navigate("game/$n") })
            }
            composable("game/{level}", arguments = listOf(navArgument("level") { type = NavType.IntType })) { e ->
                val lv = e.arguments?.getInt("level") ?: 1
                GameScreen(
                    level = lv, store = store, sound = sound, recorder = recorder,
                    onBack = { nav.popBackStack() },
                    onNext = { nav.navigate("game/${lv + 1}") { popUpTo("map") } },
                    onMap = { nav.popBackStack("map", false) }
                )
            }
        }
        if (showSettings) SettingsPanel(store) { showSettings = false }
    }
}

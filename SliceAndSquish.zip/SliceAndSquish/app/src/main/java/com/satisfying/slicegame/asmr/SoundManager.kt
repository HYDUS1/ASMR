package com.satisfying.slicegame.asmr

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.HapticFeedbackConstants
import android.view.View

enum class Snd(val res: Int) {
    CUT_SOAP(R.raw.cut_soap),
    CUT_SAND(R.raw.cut_sand),
    SQUISH(R.raw.squish_slime),
    TAP(R.raw.tap),
    CRUNCH(R.raw.crunch),
    POUR(R.raw.pour),
    SCRATCH(R.raw.scratch)
}

@Suppress("DEPRECATION")
class SoundManager(context: Context) {
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(12)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()
    private val ids = HashMap<Snd, Int>()
    private val loops = HashMap<Snd, Int>()
    private val vibrator: Vibrator? = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    private var lastHaptic = 0L

    var soundOn = true
    var hapticOn = true
    var view: View? = null

    init {
        for (s in Snd.values()) ids[s] = pool.load(context, s.res, 1)
    }

    fun play(s: Snd, rate: Float = 1f, vol: Float = 1f) {
        if (!soundOn) return
        val id = ids[s] ?: return
        pool.play(id, vol, vol, 1, 0, rate.coerceIn(0.5f, 2f))
    }

    fun startLoop(s: Snd) {
        if (!soundOn || loops.containsKey(s)) return
        val id = ids[s] ?: return
        val sid = pool.play(id, 0.8f, 0.8f, 1, -1, 1f)
        if (sid != 0) loops[s] = sid
    }

    fun stopLoop(s: Snd) {
        loops.remove(s)?.let { pool.stop(it) }
    }

    fun stopAllLoops() {
        for (s in loops.keys.toList()) stopLoop(s)
    }

    /** 15 ms tick. strong=true adds a system haptic constant on top. */
    fun haptic(strong: Boolean = false) {
        if (!hapticOn) return
        val now = System.currentTimeMillis()
        if (now - lastHaptic < 35) return
        lastHaptic = now
        val v = vibrator
        if (v != null && v.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(15)
            }
        } else {
            view?.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
        if (strong) view?.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
    }

    fun release() {
        stopAllLoops()
        pool.release()
    }
}

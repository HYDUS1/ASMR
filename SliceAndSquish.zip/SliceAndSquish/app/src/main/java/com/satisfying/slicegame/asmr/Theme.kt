package com.satisfying.slicegame.asmr

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Neon {
    val Bg0 = Color(0xFF07060F)
    val Bg1 = Color(0xFF1A1040)
    val Pink = Color(0xFFFF2E9A)
    val Cyan = Color(0xFF22F0FF)
    val Lime = Color(0xFFB6FF3B)
    val Yellow = Color(0xFFFFD83B)
    val Purple = Color(0xFF8A4DFF)
    val Panel = Color(0xCC14102B)
    val bgBrush = Brush.verticalGradient(listOf(Bg0, Bg1, Bg0))
}

fun Modifier.neonGlow(color: Color, corner: Dp = 16.dp, radius: Dp = 14.dp): Modifier = drawBehind {
    val r = corner.toPx()
    for (i in 1..5) {
        drawRoundRect(
            color = color.copy(alpha = 0.07f),
            cornerRadius = CornerRadius(r, r),
            style = Stroke(width = radius.toPx() * i / 2.5f)
        )
    }
}

@Composable
fun GlowText(text: String, color: Color, size: Int, modifier: Modifier = Modifier, weight: FontWeight = FontWeight.Black) {
    Text(
        text, modifier = modifier, color = Color.White, fontSize = size.sp, fontWeight = weight,
        style = TextStyle(shadow = Shadow(color, Offset.Zero, 28f))
    )
}

@Composable
fun NeonButton(text: String, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier, size: Int = 20) {
    Box(
        modifier = modifier
            .neonGlow(color, 28.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.horizontalGradient(listOf(color, color.copy(alpha = 0.65f))))
            .clickable(onClick = onClick)
            .padding(horizontal = 34.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.Black, fontSize = size.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
fun Chip(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .neonGlow(color, 14.dp, 8.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Neon.Panel)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

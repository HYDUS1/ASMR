package com.satisfying.slicegame.asmr

import android.content.res.AssetManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.ui.geometry.Offset
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

// =====================================================================================
//  Triangle-soup mesh: 9 floats per triangle, one flat colour per triangle.
// =====================================================================================
class Mesh(val v: FloatArray, val col: IntArray, val cap: BooleanArray) {
    val n: Int get() = col.size

    private fun tetra(t: Int): Float {
        val i = t * 9
        val ax = v[i]; val ay = v[i + 1]; val az = v[i + 2]
        val bx = v[i + 3]; val by = v[i + 4]; val bz = v[i + 5]
        val cx = v[i + 6]; val cy = v[i + 7]; val cz = v[i + 8]
        return (ax * (by * cz - bz * cy) + ay * (bz * cx - bx * cz) + az * (bx * cy - by * cx)) / 6f
    }

    fun volume(): Float { var s = 0f; for (t in 0 until n) s += tetra(t); return s }

    /** volume-weighted centroid */
    fun centroid(): FloatArray {
        val c = FloatArray(3); var tot = 0f
        for (t in 0 until n) {
            val i = t * 9
            val vol = tetra(t)
            c[0] += vol * (v[i] + v[i + 3] + v[i + 6]) / 4f
            c[1] += vol * (v[i + 1] + v[i + 4] + v[i + 7]) / 4f
            c[2] += vol * (v[i + 2] + v[i + 5] + v[i + 8]) / 4f
            tot += vol
        }
        if (abs(tot) < 1e-9f) {
            var sx = 0f; var sy = 0f; var sz = 0f
            val cnt = n * 3
            for (k in 0 until cnt) { sx += v[k * 3]; sy += v[k * 3 + 1]; sz += v[k * 3 + 2] }
            return floatArrayOf(sx / max(1, cnt), sy / max(1, cnt), sz / max(1, cnt))
        }
        c[0] /= tot; c[1] /= tot; c[2] /= tot
        return c
    }

    fun shifted(dx: Float, dy: Float, dz: Float): Mesh {
        val o = FloatArray(v.size)
        var k = 0
        while (k < v.size) { o[k] = v[k] - dx; o[k + 1] = v[k + 1] - dy; o[k + 2] = v[k + 2] - dz; k += 3 }
        return Mesh(o, col, cap)
    }

    fun radius(): Float {
        var m = 0f
        var k = 0
        while (k < v.size) { m = max(m, sqrt(v[k] * v[k] + v[k + 1] * v[k + 1] + v[k + 2] * v[k + 2])); k += 3 }
        return m
    }
}

// =====================================================================================
//  OBJ loading (Kenney Food Kit: every model samples one colour-palette PNG)
// =====================================================================================
class FoodDef(val file: String, val cap: Int)

object Models {
    val foods = listOf(
        FoodDef("apple", 0xFFF6EBC0.toInt()),
        FoodDef("watermelon", 0xFFE8344E.toInt()),
        FoodDef("orange", 0xFFFFA630.toInt()),
        FoodDef("lemon", 0xFFFFE86B.toInt()),
        FoodDef("tomato", 0xFFE03A2E.toInt()),
        FoodDef("loaf-round", 0xFFF1D6A0.toInt()),
        FoodDef("pumpkin", 0xFFFF9A2B.toInt()),
        FoodDef("carrot", 0xFFFF8A1F.toInt()),
        FoodDef("avocado", 0xFFC8E070.toInt()),
        FoodDef("coconut", 0xFFFFFFFF.toInt()),
        FoodDef("sausage", 0xFFD9775B.toInt())
    )

    private var palette: Bitmap? = null
    private val cache = HashMap<String, Mesh>()

    private fun idx(s: String, count: Int): Int { val i = s.toInt(); return if (i < 0) count + i else i - 1 }

    fun load(am: AssetManager, name: String, targetRadius: Float): Mesh {
        val key = "$name@$targetRadius"
        cache[key]?.let { return it }
        val pal = palette ?: BitmapFactory.decodeStream(am.open("models/colormap.png")).also { palette = it }

        val vs = ArrayList<FloatArray>()
        val vts = ArrayList<FloatArray>()
        val faces = ArrayList<IntArray>()
        am.open("models/$name.obj").bufferedReader().useLines { seq ->
            for (line in seq) {
                val p = line.trim().split(Regex("\\s+"))
                if (p.size < 2) continue
                when (p[0]) {
                    "v" -> vs.add(floatArrayOf(p[1].toFloat(), p[2].toFloat(), p[3].toFloat()))
                    "vt" -> vts.add(floatArrayOf(p[1].toFloat(), p[2].toFloat()))
                    "f" -> {
                        val a = IntArray((p.size - 1) * 2)
                        for (k in 1 until p.size) {
                            val s = p[k].split("/")
                            a[(k - 1) * 2] = idx(s[0], vs.size)
                            a[(k - 1) * 2 + 1] = if (s.size > 1 && s[1].isNotEmpty()) idx(s[1], vts.size) else -1
                        }
                        faces.add(a)
                    }
                }
            }
        }

        val pos = ArrayList<Float>()
        val cols = ArrayList<Int>()
        val seen = HashSet<String>()
        for (a in faces) {
            val nv = a.size / 2
            for (k in 1 until nv - 1) {
                val ids = intArrayOf(0, k, k + 1)
                val hs = LongArray(3) {
                    val vv = vs[a[ids[it] * 2]]
                    ((vv[0] * 1e4f).roundToInt().toLong() * 73856093L) xor
                        ((vv[1] * 1e4f).roundToInt().toLong() * 19349663L) xor
                        ((vv[2] * 1e4f).roundToInt().toLong() * 83492791L)
                }
                hs.sort()
                if (!seen.add("${hs[0]},${hs[1]},${hs[2]}")) continue
                var u = 0f; var v = 0f; var cnt = 0
                for (q in ids) {
                    val ti = a[q * 2 + 1]
                    if (ti >= 0 && ti < vts.size) { u += vts[ti][0]; v += vts[ti][1]; cnt++ }
                }
                var color = 0xFFC0C0C0.toInt()
                if (cnt > 0) {
                    u /= cnt; v /= cnt
                    val px = (u * pal.width).toInt().coerceIn(0, pal.width - 1)
                    val py = ((1f - v) * pal.height).toInt().coerceIn(0, pal.height - 1)
                    color = pal.getPixel(px, py)
                }
                for (q in ids) {
                    val vv = vs[a[q * 2]]
                    pos.add(vv[0]); pos.add(vv[1]); pos.add(vv[2])
                }
                cols.add(color or 0xFF000000.toInt())
            }
        }

        // normalise: centre on bounding box, scale so bounding radius = targetRadius
        var mnx = 1e9f; var mny = 1e9f; var mnz = 1e9f; var mxx = -1e9f; var mxy = -1e9f; var mxz = -1e9f
        var i = 0
        while (i < pos.size) {
            mnx = min(mnx, pos[i]); mxx = max(mxx, pos[i])
            mny = min(mny, pos[i + 1]); mxy = max(mxy, pos[i + 1])
            mnz = min(mnz, pos[i + 2]); mxz = max(mxz, pos[i + 2])
            i += 3
        }
        val cx = (mnx + mxx) / 2; val cy = (mny + mxy) / 2; val cz = (mnz + mxz) / 2
        val hx = (mxx - mnx) / 2; val hy = (mxy - mny) / 2; val hz = (mxz - mnz) / 2
        val scale = targetRadius / max(1e-6f, sqrt(hx * hx + hy * hy + hz * hz))
        val arr = FloatArray(pos.size)
        i = 0
        while (i < pos.size) {
            arr[i] = (pos[i] - cx) * scale; arr[i + 1] = (pos[i + 1] - cy) * scale; arr[i + 2] = (pos[i + 2] - cz) * scale
            i += 3
        }
        var mesh = Mesh(arr, cols.toIntArray(), BooleanArray(cols.size))
        if (mesh.volume() < 0f) {              // inside-out winding: flip
            for (t in 0 until mesh.n) {
                val b = t * 9
                for (k in 0..2) { val tmp = arr[b + 3 + k]; arr[b + 3 + k] = arr[b + 6 + k]; arr[b + 6 + k] = tmp }
            }
            mesh = Mesh(arr, mesh.col, mesh.cap)
        }
        cache[key] = mesh
        return mesh
    }
}

// =====================================================================================
//  Plane slicing of a triangle mesh (+ capping the cut with flat "flesh" faces)
// =====================================================================================
object SliceMesh {
    class Result(val a: Mesh, val b: Mesh)

    private class Out {
        val v = ArrayList<Float>(); val c = ArrayList<Int>(); val cap = ArrayList<Boolean>()
        fun tri(p: FloatArray, q: FloatArray, r: FloatArray, col: Int, isCap: Boolean) {
            v.add(p[0]); v.add(p[1]); v.add(p[2]); v.add(q[0]); v.add(q[1]); v.add(q[2]); v.add(r[0]); v.add(r[1]); v.add(r[2])
            c.add(col); cap.add(isCap)
        }
        fun mesh() = Mesh(v.toFloatArray(), c.toIntArray(), cap.toBooleanArray())
    }

    private fun dist(a: FloatArray, b: FloatArray, o: Int): Float {
        val dx = a[0] - b[o]; val dy = a[1] - b[o + 1]; val dz = a[2] - b[o + 2]
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    /** Plane: n . p = d (mesh-local). Side A is where n . p > d. Returns null if the plane doesn't cut the mesh. */
    fun split(m: Mesh, nx: Float, ny: Float, nz: Float, d: Float, capCol: Int): Result? {
        val A = Out(); val B = Out()
        val segs = ArrayList<FloatArray>()
        val s = FloatArray(3)
        val P = Array(3) { FloatArray(3) }
        for (t in 0 until m.n) {
            val i = t * 9
            for (k in 0..2) {
                P[k][0] = m.v[i + k * 3]; P[k][1] = m.v[i + k * 3 + 1]; P[k][2] = m.v[i + k * 3 + 2]
                var sv = nx * P[k][0] + ny * P[k][1] + nz * P[k][2] - d
                if (abs(sv) < 1e-6f) sv = 1e-6f
                s[k] = sv
            }
            val col = m.col[t]; val cp = m.cap[t]
            if (s[0] > 0f && s[1] > 0f && s[2] > 0f) { A.tri(P[0], P[1], P[2], col, cp); continue }
            if (s[0] < 0f && s[1] < 0f && s[2] < 0f) { B.tri(P[0], P[1], P[2], col, cp); continue }
            val pa = ArrayList<FloatArray>(4); val pb = ArrayList<FloatArray>(4); val cut = ArrayList<FloatArray>(2)
            for (k in 0..2) {
                val cur = P[k].copyOf(); val nxt = P[(k + 1) % 3]
                val sc = s[k]; val sn = s[(k + 1) % 3]
                if (sc > 0f) pa.add(cur) else pb.add(cur)
                if ((sc > 0f) != (sn > 0f)) {
                    val tt = sc / (sc - sn)
                    val ip = floatArrayOf(cur[0] + (nxt[0] - cur[0]) * tt, cur[1] + (nxt[1] - cur[1]) * tt, cur[2] + (nxt[2] - cur[2]) * tt)
                    pa.add(ip); pb.add(ip); cut.add(ip)
                }
            }
            for (k in 1 until pa.size - 1) A.tri(pa[0], pa[k], pa[k + 1], col, cp)
            for (k in 1 until pb.size - 1) B.tri(pb[0], pb[k], pb[k + 1], col, cp)
            if (cut.size == 2) segs.add(floatArrayOf(cut[0][0], cut[0][1], cut[0][2], cut[1][0], cut[1][1], cut[1][2]))
        }

        // chain cut segments into closed loops and fill them with fan caps
        val tol = 2e-3f
        val used = BooleanArray(segs.size)
        for (i in segs.indices) {
            if (used[i]) continue
            used[i] = true
            val sg = segs[i]
            val loop = ArrayList<FloatArray>()
            loop.add(floatArrayOf(sg[0], sg[1], sg[2]))
            var cur = floatArrayOf(sg[3], sg[4], sg[5])
            loop.add(cur)
            while (true) {
                var found = -1; var rev = false
                for (j in segs.indices) {
                    if (used[j]) continue
                    val o = segs[j]
                    if (dist(cur, o, 0) < tol) { found = j; rev = false; break }
                    if (dist(cur, o, 3) < tol) { found = j; rev = true; break }
                }
                if (found < 0) break
                used[found] = true
                val o = segs[found]
                val next = if (!rev) floatArrayOf(o[3], o[4], o[5]) else floatArrayOf(o[0], o[1], o[2])
                if (dist(next, loop[0], 0) < tol) break
                loop.add(next); cur = next
            }
            if (loop.size < 3) continue
            val c = FloatArray(3)
            for (p in loop) { c[0] += p[0]; c[1] += p[1]; c[2] += p[2] }
            val inv = 1f / loop.size.toFloat()
            c[0] = c[0] * inv; c[1] = c[1] * inv; c[2] = c[2] * inv
            var sgn = 0f
            for (k in loop.indices) {
                val p = loop[k]; val q = loop[(k + 1) % loop.size]
                val ax = p[0] - c[0]; val ay = p[1] - c[1]; val az = p[2] - c[2]
                val bx = q[0] - c[0]; val by = q[1] - c[1]; val bz = q[2] - c[2]
                sgn += (ay * bz - az * by) * nx + (az * bx - ax * bz) * ny + (ax * by - ay * bx) * nz
            }
            for (k in loop.indices) {
                val p = loop[k]; val q = loop[(k + 1) % loop.size]
                // side A: outward normal = -n ; side B: outward normal = +n
                if (sgn < 0f) A.tri(c, p, q, capCol, true) else A.tri(c, q, p, capCol, true)
                if (sgn > 0f) B.tri(c, p, q, capCol, true) else B.tri(c, q, p, capCol, true)
            }
        }
        val ma = A.mesh(); val mb = B.mesh()
        if (ma.n < 4 || mb.n < 4) return null
        return Result(ma, mb)
    }
}

// =====================================================================================
//  Small matrix helpers (row-major 3x3)
// =====================================================================================
private fun matMul(a: FloatArray, b: FloatArray): FloatArray {
    val r = FloatArray(9)
    for (i in 0..2) for (j in 0..2) { var s = 0f; for (k in 0..2) s += a[i * 3 + k] * b[k * 3 + j]; r[i * 3 + j] = s }
    return r
}
private fun rodrigues(ax: Float, ay: Float, az: Float, ang: Float): FloatArray {
    val c = cos(ang); val s = sin(ang); val t = 1f - c
    return floatArrayOf(
        t * ax * ax + c, t * ax * ay - s * az, t * ax * az + s * ay,
        t * ax * ay + s * az, t * ay * ay + c, t * ay * az - s * ax,
        t * ax * az - s * ay, t * ay * az + s * ax, t * az * az + c
    )
}

class Piece3D(var mesh: Mesh) {
    var px = 0f; var py = 0f; var pz = 0f
    var R = floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f)
    var vx = 0f; var vy = 0f; var vz = 0f
    var wx = 0f; var wy = 0f; var wz = 0f
    var floating = false; var resting = false; var dying = false
    var hasCap = false; var capNx = 0f; var capNy = 0f; var capNz = 0f
    var volume = 0f; var radius = 0f; var fade = 1f; var restTime = 0f; var phase = 0f; var baseY = 1.5f
    var id = 0
}

// =====================================================================================
//  The 3D slicing level: perspective camera, lighting, physics, cutting, knife
// =====================================================================================
class Slice3D(private val am: AssetManager, private val world: GameWorld, private val level: LevelDef) {

    companion object {
        const val FOCAL = 1400f
        const val CY0 = 900f
        const val G = 0.0032f
        private const val CAMX = 0f; private const val CAMY = 2.4f; private const val CAMZ = 6.2f
    }

    // camera basis
    private val fx: Float; private val fy: Float; private val fz: Float
    private val rx: Float; private val ry: Float; private val rz: Float
    private val ux: Float; private val uy: Float; private val uz: Float
    // light direction (towards the light)
    private val lx = -0.45f; private val ly = 0.75f; private val lz = 0.5f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val groups = HashMap<Int, Path>()
    private val inUse = ArrayList<Int>()
    private var wv = FloatArray(0)
    private var sv = FloatArray(0)

    private val pieces = ArrayList<Piece3D>()
    private var nextId = 1
    private var spawnIdx = 0
    private var capColor = 0xFFFFFFFF.toInt()
    private var v0 = 1f
    private var minVol = 0.01f
    private var respawn = 0f
    private var time = 0f

    private val entry = HashMap<Int, Offset>()
    private val last = HashMap<Int, Offset>()

    private val knifeMesh: Mesh = Models.load(am, "cooking-knife", 1.2f)
    private var knifeMinX = 0f
    private var kx = 540f; private var ky = 900f; private var kdx = 1f; private var kdy = 0.3f
    private var knifeA = 0f

    init {
        val tx = 0f; val ty = 0.9f; val tz = 0f
        var dx = tx - CAMX; var dy = ty - CAMY; var dz = tz - CAMZ
        val dl = sqrt(dx * dx + dy * dy + dz * dz)
        fx = dx / dl; fy = dy / dl; fz = dz / dl
        // right = f x up(0,1,0)
        var rxx = -fz; var ryy = 0f; var rzz = fx
        val rl = sqrt(rxx * rxx + rzz * rzz)
        rx = rxx / rl; ry = ryy; rz = rzz / rl
        // up = r x f
        ux = ry * fz - rz * fy; uy = rz * fx - rx * fz; uz = rx * fy - ry * fx
        var mn = 1e9f
        var k = 0
        while (k < knifeMesh.v.size) { mn = min(mn, knifeMesh.v[k]); k += 3 }
        knifeMinX = mn
        spawn()
    }

    // ------------------------------------------------------------ helpers
    private fun rayDir(sx: Float, sy: Float): FloatArray {
        val xc = (sx - 540f) / FOCAL; val yc = (CY0 - sy) / FOCAL
        val x = rx * xc + ux * yc + fx; val y = ry * xc + uy * yc + fy; val z = rz * xc + uz * yc + fz
        val l = sqrt(x * x + y * y + z * z)
        return floatArrayOf(x / l, y / l, z / l)
    }

    private fun proj(x: Float, y: Float, z: Float, out: FloatArray) {
        val dx = x - CAMX; val dy = y - CAMY; val dz = z - CAMZ
        val xc = dx * rx + dy * ry + dz * rz
        val yc = dx * ux + dy * uy + dz * uz
        var zc = dx * fx + dy * fy + dz * fz
        if (zc < 0.2f) zc = 0.2f
        out[0] = 540f + FOCAL * xc / zc
        out[1] = CY0 - FOCAL * yc / zc
        out[2] = zc
    }

    private fun lowestY(pc: Piece3D): Float {
        val v = pc.mesh.v; val R = pc.R
        var mn = 1e9f
        var i = 0
        while (i < v.size) {
            val y = R[3] * v[i] + R[4] * v[i + 1] + R[5] * v[i + 2]
            if (y < mn) mn = y
            i += 3
        }
        return mn
    }

    // ------------------------------------------------------------ spawn
    private fun spawn() {
        for (p in pieces) p.dying = true
        val fd = Models.foods[(level.number * 3 + spawnIdx++) % Models.foods.size]
        val mesh = Models.load(am, fd.file, 1.3f)
        capColor = fd.cap
        val pc = Piece3D(mesh)
        pc.id = nextId++
        pc.floating = true; pc.py = 1.5f; pc.baseY = 1.5f
        pc.R = rodrigues(1f, 0f, 0f, -0.35f)
        pc.volume = mesh.volume(); pc.radius = mesh.radius()
        v0 = pc.volume; minVol = v0 * 0.035f
        pieces.add(pc)
    }

    // ------------------------------------------------------------ input
    fun down(id: Int, x: Float, y: Float) { last[id] = Offset(x, y); kx = x; ky = y }

    fun move(id: Int, x: Float, y: Float) {
        val a = last[id] ?: return
        val b = Offset(x, y)
        val dist = (b - a).getDistance()
        if (dist < 3f) return
        kdx += ((b.x - a.x) / dist - kdx) * 0.35f
        kdy += ((b.y - a.y) / dist - kdy) * 0.35f
        kx = x; ky = y
        swipe(a, b)
        last[id] = b
    }

    fun up(id: Int) { last.remove(id); entry.clear() }

    private fun hull(pts: MutableList<Offset>): List<Offset> {
        pts.sortWith(compareBy<Offset>({ it.x }, { it.y }))
        if (pts.size < 3) return pts
        fun cr(o: Offset, a: Offset, b: Offset) = (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x)
        val h = ArrayList<Offset>()
        for (p in pts) {
            while (h.size >= 2 && cr(h[h.size - 2], h[h.size - 1], p) <= 0f) h.removeAt(h.size - 1)
            h.add(p)
        }
        val lower = h.size + 1
        for (i in pts.size - 2 downTo 0) {
            val p = pts[i]
            while (h.size >= lower && cr(h[h.size - 2], h[h.size - 1], p) <= 0f) h.removeAt(h.size - 1)
            h.add(p)
        }
        h.removeAt(h.size - 1)
        return h
    }

    private fun silhouette(pc: Piece3D): List<Offset> {
        val v = pc.mesh.v; val R = pc.R
        val out = FloatArray(3)
        val pts = ArrayList<Offset>(v.size / 3)
        var i = 0
        while (i < v.size) {
            val x = v[i]; val y = v[i + 1]; val z = v[i + 2]
            proj(pc.px + R[0] * x + R[1] * y + R[2] * z, pc.py + R[3] * x + R[4] * y + R[5] * z, pc.pz + R[6] * x + R[7] * y + R[8] * z, out)
            pts.add(Offset(out[0], out[1]))
            i += 3
        }
        return hull(pts)
    }

    private fun swipe(a: Offset, b: Offset) {
        for (pc in pieces.toList()) {
            if (pc.dying || pc.volume < minVol * 2.2f) continue
            val hits = segmentPolygonHits(a, b, silhouette(pc))
            if (hits.size >= 2) {
                entry.remove(pc.id)
                cutPiece(pc, hits.first(), hits.last())
            } else if (hits.size == 1) {
                val e = entry[pc.id]
                if (e == null) entry[pc.id] = hits[0]
                else {
                    entry.remove(pc.id)
                    if ((e - hits[0]).getDistance() > 14f) cutPiece(pc, e, hits[0])
                }
            }
        }
    }

    // ------------------------------------------------------------ cutting
    private fun cutPiece(pc: Piece3D, p1: Offset, p2: Offset) {
        val da = rayDir(p1.x, p1.y); val db = rayDir(p2.x, p2.y)
        var nx = da[1] * db[2] - da[2] * db[1]
        var ny = da[2] * db[0] - da[0] * db[2]
        var nz = da[0] * db[1] - da[1] * db[0]
        val nl = sqrt(nx * nx + ny * ny + nz * nz)
        if (nl < 1e-6f) return
        nx /= nl; ny /= nl; nz /= nl
        val d = nx * CAMX + ny * CAMY + nz * CAMZ
        val R = pc.R
        // plane into mesh-local space: nl = R^T n
        val lnx = R[0] * nx + R[3] * ny + R[6] * nz
        val lny = R[1] * nx + R[4] * ny + R[7] * nz
        val lnz = R[2] * nx + R[5] * ny + R[8] * nz
        val ld = d - (nx * pc.px + ny * pc.py + nz * pc.pz)
        val res = SliceMesh.split(pc.mesh, lnx, lny, lnz, ld, capColor) ?: return
        val volA = res.a.volume(); val volB = res.b.volume()
        if (volA < minVol || volB < minVol) return

        val kids = ArrayList<Piece3D>()
        for (k in 0..1) {
            val mesh = if (k == 0) res.a else res.b
            val sgn = if (k == 0) 1f else -1f
            val c = mesh.centroid()
            val kid = Piece3D(mesh.shifted(c[0], c[1], c[2]))
            kid.id = nextId++
            kid.R = pc.R.copyOf()
            kid.px = pc.px + R[0] * c[0] + R[1] * c[1] + R[2] * c[2] + nx * sgn * 0.01f
            kid.py = pc.py + R[3] * c[0] + R[4] * c[1] + R[5] * c[2] + ny * sgn * 0.01f
            kid.pz = pc.pz + R[6] * c[0] + R[7] * c[1] + R[8] * c[2] + nz * sgn * 0.01f
            val sep = 0.028f
            kid.vx = pc.vx + nx * sgn * sep
            kid.vy = pc.vy + ny * sgn * sep + (if (pc.resting) 0.03f else 0f)
            kid.vz = pc.vz + nz * sgn * sep
            if (abs(ny) > 0.7f) kid.vx += sgn * 0.014f
            kid.wx = pc.wx + (Random.nextFloat() - 0.5f) * 0.05f
            kid.wy = pc.wy + (Random.nextFloat() - 0.5f) * 0.05f
            kid.wz = pc.wz + (Random.nextFloat() - 0.5f) * 0.05f
            kid.hasCap = true
            kid.capNx = -lnx * sgn; kid.capNy = -lny * sgn; kid.capNz = -lnz * sgn
            kid.volume = if (k == 0) volA else volB
            kid.radius = kid.mesh.radius()
            kids.add(kid)
        }
        pieces.remove(pc)
        pieces.addAll(kids)
        val ratio = min(volA, volB) / (volA + volB)
        world.onCut3D(ratio, p1.x, p1.y, p2.x, p2.y, capColor)
    }

    // ------------------------------------------------------------ update
    fun update(dt: Float, f: Float) {
        time += dt
        for (pc in pieces) {
            if (pc.floating) {
                pc.phase += dt * 1.8f
                pc.py = pc.baseY + sin(pc.phase) * 0.06f
                pc.R = matMul(rodrigues(0f, 1f, 0f, dt * 0.7f), pc.R)
                continue
            }
            if (pc.dying) { pc.fade -= dt * 2.5f; continue }
            if (!pc.resting) {
                pc.vy -= G * f
                pc.px += pc.vx * f; pc.py += pc.vy * f; pc.pz += pc.vz * f
                val ang = sqrt(pc.wx * pc.wx + pc.wy * pc.wy + pc.wz * pc.wz)
                if (ang > 1e-5f) pc.R = matMul(rodrigues(pc.wx / ang, pc.wy / ang, pc.wz / ang, ang * f), pc.R)
                val low = pc.py + lowestY(pc)
                if (low <= 0f) {
                    pc.py -= low
                    if (pc.vy < -0.03f) {
                        pc.vy = -pc.vy * 0.25f; pc.vx *= 0.7f; pc.vz *= 0.7f
                        pc.wx *= 0.5f; pc.wy *= 0.5f; pc.wz *= 0.5f
                    } else {
                        pc.vx = 0f; pc.vy = 0f; pc.vz = 0f; pc.wx = 0f; pc.wy = 0f; pc.wz = 0f
                        pc.resting = true; pc.restTime = 0f
                    }
                }
                if (pc.px < -2.4f) { pc.px = -2.4f; pc.vx = abs(pc.vx) * 0.4f }
                if (pc.px > 2.4f) { pc.px = 2.4f; pc.vx = -abs(pc.vx) * 0.4f }
                if (pc.pz < -1.8f) { pc.pz = -1.8f; pc.vz = abs(pc.vz) * 0.4f }
                if (pc.pz > 2.2f) { pc.pz = 2.2f; pc.vz = -abs(pc.vz) * 0.4f }
            } else {
                if (pc.hasCap) {
                    val R = pc.R
                    val wx = R[0] * pc.capNx + R[1] * pc.capNy + R[2] * pc.capNz
                    val wy = R[3] * pc.capNx + R[4] * pc.capNy + R[5] * pc.capNz
                    val wz = R[6] * pc.capNx + R[7] * pc.capNy + R[8] * pc.capNz
                    // want cap normal to point down (0,-1,0): axis = n x down
                    val ax = wz; val ay = 0f; val az = -wx
                    val sinA = sqrt(ax * ax + az * az)
                    val cosA = -wy
                    if (sinA > 1e-4f) {
                        val angle = Math.atan2(sinA.toDouble(), cosA.toDouble()).toFloat()
                        val step = angle * (1f - 0.8f.let { Math.pow(it.toDouble(), f.toDouble()).toFloat() })
                        pc.R = matMul(rodrigues(ax / sinA, ay / sinA, az / sinA, step), pc.R)
                    }
                }
                pc.py = -lowestY(pc)
                pc.restTime += dt
                if (pc.volume < minVol * 2.2f && pc.restTime > 3f) pc.dying = true
            }
        }
        pieces.removeAll { it.fade <= 0f || it.py < -5f }
        if (pieces.size > 22) pieces.filter { !it.dying }.take(pieces.size - 22).forEach { it.dying = true }
        knifeA += ((if (last.isNotEmpty() && !world.completed) 1f else 0f) - knifeA) * min(1f, dt * 12f)
        if (!world.completed) {
            val big = pieces.any { !it.dying && it.volume >= minVol * 2.2f }
            if (!big) { respawn += dt; if (respawn > 0.8f) { respawn = 0f; spawn() } } else respawn = 0f
        }
    }

    // ------------------------------------------------------------ rendering
    private fun fillP(color: Int) { paint.style = Paint.Style.FILL; paint.shader = null; paint.color = color }

    fun render(c: Canvas) {
        drawTable(c)
        val sorted = pieces.sortedByDescending { (it.px - CAMX) * fx + (it.py - CAMY) * fy + (it.pz - CAMZ) * fz }
        for (pc in sorted) {
            drawShadow(c, pc)
            drawMesh(c, pc.mesh, pc.px, pc.py, pc.pz, pc.R, pc.fade)
        }
        drawKnife(c)
    }

    private fun drawTable(c: Canvas) {
        val p = FloatArray(3)
        val zs = floatArrayOf(-3f, 4.4f)
        val xs = floatArrayOf(-6f, 6f)
        val q = Array(4) { FloatArray(3) }
        proj(xs[0], 0f, zs[0], q[0]); proj(xs[1], 0f, zs[0], q[1]); proj(xs[1], 0f, zs[1], q[2]); proj(xs[0], 0f, zs[1], q[3])
        path.reset()
        path.moveTo(q[0][0], q[0][1]); path.lineTo(q[1][0], q[1][1]); path.lineTo(q[2][0], q[2][1]); path.lineTo(q[3][0], q[3][1]); path.close()
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, q[0][1], 0f, 1920f, 0xFF3A2466.toInt(), 0xFF140C2B.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, paint); paint.shader = null
        // perspective grid
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = 0x2222F0FF
        val a = FloatArray(3); val b = FloatArray(3)
        var x = -6f
        while (x <= 6f) { proj(x, 0f, -3f, a); proj(x, 0f, 4.4f, b); c.drawLine(a[0], a[1], b[0], b[1], paint); x += 1f }
        var z = -3f
        while (z <= 4.4f) { proj(-6f, 0f, z, a); proj(6f, 0f, z, b); c.drawLine(a[0], a[1], b[0], b[1], paint); z += 1f }
        paint.color = 0xAA22F0FF.toInt(); paint.strokeWidth = 5f
        c.drawLine(q[0][0], q[0][1], q[1][0], q[1][1], paint)
        paint.style = Paint.Style.FILL
    }

    private fun drawShadow(c: Canvas, pc: Piece3D) {
        val o = FloatArray(3)
        proj(pc.px, 0f, pc.pz, o)
        val rad = FOCAL * pc.radius * 0.9f / o[2]
        val a = (0.42f * (1f - min(1f, pc.py / 3.2f)) * pc.fade).coerceIn(0f, 1f)
        fillP(((a * 255f).toInt() shl 24))
        rect.set(o[0] - rad, o[1] - rad * 0.28f, o[0] + rad, o[1] + rad * 0.28f)
        c.drawOval(rect, paint)
    }

    private fun drawMesh(c: Canvas, mesh: Mesh, px: Float, py: Float, pz: Float, R: FloatArray, fade: Float) {
        val nvert = mesh.n * 3
        if (wv.size < nvert * 3) { wv = FloatArray(nvert * 3); sv = FloatArray(nvert * 2) }
        val mv = mesh.v
        for (i in 0 until nvert) {
            val x = mv[i * 3]; val y = mv[i * 3 + 1]; val z = mv[i * 3 + 2]
            val wx = px + R[0] * x + R[1] * y + R[2] * z
            val wy = py + R[3] * x + R[4] * y + R[5] * z
            val wz = pz + R[6] * x + R[7] * y + R[8] * z
            wv[i * 3] = wx; wv[i * 3 + 1] = wy; wv[i * 3 + 2] = wz
            val dx = wx - CAMX; val dy = wy - CAMY; val dz = wz - CAMZ
            val xc = dx * rx + dy * ry + dz * rz
            val yc = dx * ux + dy * uy + dz * uz
            var zc = dx * fx + dy * fy + dz * fz
            if (zc < 0.2f) zc = 0.2f
            sv[i * 2] = 540f + FOCAL * xc / zc
            sv[i * 2 + 1] = CY0 - FOCAL * yc / zc
        }
        inUse.clear()
        val al = (fade.coerceIn(0f, 1f) * 255f).toInt()
        for (t in 0 until mesh.n) {
            val b = t * 9
            val ax = wv[b]; val ay = wv[b + 1]; val az = wv[b + 2]
            val e1x = wv[b + 3] - ax; val e1y = wv[b + 4] - ay; val e1z = wv[b + 5] - az
            val e2x = wv[b + 6] - ax; val e2y = wv[b + 7] - ay; val e2z = wv[b + 8] - az
            var nx = e1y * e2z - e1z * e2y
            var ny = e1z * e2x - e1x * e2z
            var nz = e1x * e2y - e1y * e2x
            if (nx * (CAMX - ax) + ny * (CAMY - ay) + nz * (CAMZ - az) <= 0f) continue   // back face
            val nl = sqrt(nx * nx + ny * ny + nz * nz)
            if (nl < 1e-9f) continue
            nx /= nl; ny /= nl; nz /= nl
            val ndl = nx * lx + ny * ly + nz * lz
            val shade = 0.42f + 0.58f * max(0f, ndl)
            val spec = if (ndl > 0.86f && !mesh.cap[t]) (ndl - 0.86f) * 260f else 0f
            val col = mesh.col[t]
            val r = min(255, (((col shr 16) and 255) * shade + spec).toInt())
            val g = min(255, (((col shr 8) and 255) * shade + spec).toInt())
            val bl = min(255, ((col and 255) * shade + spec).toInt())
            val key = ((r shr 3) shl 10) or ((g shr 3) shl 5) or (bl shr 3)
            var pth = groups[key]
            if (pth == null) { pth = Path(); groups[key] = pth }
            if (!inUse.contains(key)) inUse.add(key)
            pth.moveTo(sv[t * 6], sv[t * 6 + 1]); pth.lineTo(sv[t * 6 + 2], sv[t * 6 + 3]); pth.lineTo(sv[t * 6 + 4], sv[t * 6 + 5]); pth.close()
        }
        for (key in inUse) {
            val pth = groups[key] ?: continue
            val rr = (((key shr 10) and 31) shl 3) or 4
            val gg = (((key shr 5) and 31) shl 3) or 4
            val bb = ((key and 31) shl 3) or 4
            val color = (al shl 24) or (rr shl 16) or (gg shl 8) or bb
            paint.style = Paint.Style.FILL; paint.shader = null; paint.color = color
            c.drawPath(pth, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.6f; paint.strokeJoin = Paint.Join.ROUND
            c.drawPath(pth, paint)
            pth.reset()
        }
        paint.style = Paint.Style.FILL
    }

    private fun drawKnife(c: Canvas) {
        if (knifeA < 0.03f) return
        val dir = rayDir(kx, ky)
        val dist = 6.2f / (dir[0] * fx + dir[1] * fy + dir[2] * fz)
        val tx = CAMX + dir[0] * dist; val ty = CAMY + dir[1] * dist; val tz = CAMZ + dir[2] * dist
        // swipe direction in world (camera plane)
        var sx = rx * kdx - ux * kdy; var sy = ry * kdx - uy * kdy; var sz = rz * kdx - uz * kdy
        val sl = sqrt(sx * sx + sy * sy + sz * sz)
        sx /= sl; sy /= sl; sz /= sl
        // local X -> -s (tip leads), local Y (thin axis) -> toward camera, local Z = X x Y
        val xw0 = -sx; val xw1 = -sy; val xw2 = -sz
        val yw0 = -fx; val yw1 = -fy; val yw2 = -fz
        val zw0 = xw1 * yw2 - xw2 * yw1; val zw1 = xw2 * yw0 - xw0 * yw2; val zw2 = xw0 * yw1 - xw1 * yw0
        var R = floatArrayOf(xw0, yw0, zw0, xw1, yw1, zw1, xw2, yw2, zw2)
        R = matMul(rodrigues(sx, sy, sz, 0.55f), R)
        val cx = tx - R[0] * knifeMinX; val cy = ty - R[3] * knifeMinX; val cz = tz - R[6] * knifeMinX
        c.saveLayerAlpha(null, (knifeA.coerceIn(0f, 1f) * 255f).toInt())
        drawMesh(c, knifeMesh, cx, cy, cz, R, 1f)
        c.restore()
    }
}

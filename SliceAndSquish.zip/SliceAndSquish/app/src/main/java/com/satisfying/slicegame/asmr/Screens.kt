package com.satisfying.slicegame.asmr

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

// ------------------------------------------------------------------ Start
@Composable
fun StartScreen(store: GameStore, onPlay: () -> Unit, onSettings: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "start")
    val t by inf.animateFloat(0f, 6.2831f, infiniteRepeatable(tween(9000), RepeatMode.Restart), label = "t")
    val pulse by inf.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p")
    Box(Modifier.fillMaxSize().background(Neon.bgBrush)) {
        Canvas(Modifier.fillMaxSize()) {
            val cols = listOf(Neon.Purple, Neon.Pink, Neon.Cyan, Neon.Lime)
            for (i in 0 until 14) {
                val x = size.width * ((i * 0.137f + 0.05f) % 1f) + sin(t + i) * 30f
                val y = size.height * ((i * 0.211f + 0.1f) % 1f) + cos(t * 1.3f + i) * 40f
                drawCircle(cols[i % 4].copy(alpha = 0.10f), 50f + (i % 4) * 30f, Offset(x, y))
                drawCircle(cols[i % 4].copy(alpha = 0.25f), 8f + (i % 3) * 5f, Offset(x, y))
            }
        }
        Row(Modifier.statusBarsPadding().fillMaxWidth().padding(16.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween) {
            Chip("● ${store.coins}", Neon.Yellow)
            Box(Modifier.neonGlow(Neon.Cyan, 20.dp, 8.dp).clip(CircleShape).background(Neon.Panel).clickable(onClick = onSettings).padding(10.dp)) {
                Icon(Icons.Filled.Settings, "Settings", tint = Neon.Cyan, modifier = Modifier.size(24.dp))
            }
        }
        Column(Modifier.fillMaxSize(), verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            GlowText("SLICE", Neon.Cyan, 64)
            GlowText("& SQUISH", Neon.Pink, 52)
            Spacer(Modifier.height(6.dp))
            Text("A S M R   G A M E", color = Neon.Lime, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(64.dp))
            Box(Modifier.scale(pulse)) { NeonButton("PLAY", Neon.Lime, onPlay, size = 34) }
            Spacer(Modifier.height(16.dp))
            Text("Level ${store.unlocked} / 100", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
        }
    }
}

// ------------------------------------------------------------------ Level map
@Composable
fun LevelMapScreen(store: GameStore, onBack: () -> Unit, onLevel: (Int) -> Unit) {
    val state = rememberLazyListState(initialFirstVisibleItemIndex = maxOf(0, store.unlocked - 4))
    Box(Modifier.fillMaxSize().background(Neon.bgBrush)) {
        LazyColumn(Modifier.fillMaxSize(), state = state, reverseLayout = true) {
            item { Spacer(Modifier.height(40.dp)) }
            items(LevelManager.COUNT) { idx ->
                val n = idx + 1
                val def = LevelManager.get(n)
                val open = n <= store.unlocked
                val tint = Color(def.tint)
                val col = if (open) tint else Color(0xFF3A3560)
                Box(Modifier.fillMaxWidth().height(112.dp), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.offset(x = (sin(n * 0.9f) * 100f).dp)
                            .size(76.dp)
                            .neonGlow(col, 38.dp, 10.dp)
                            .clip(CircleShape)
                            .background(Neon.Panel)
                            .clickable(enabled = open) { onLevel(n) },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$n", color = col, fontSize = 26.sp, fontWeight = FontWeight.Black)
                            if (open) {
                                val st = store.stars(n)
                                Text("★".repeat(st) + "☆".repeat(3 - st), color = Neon.Yellow, fontSize = 11.sp)
                            } else Text("LOCK", color = col, fontSize = 9.sp)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(130.dp)) }
        }
        Row(
            Modifier.statusBarsPadding().fillMaxWidth().background(Color(0xEE07060F)).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
        ) {
            Box(Modifier.clip(CircleShape).clickable(onClick = onBack).padding(8.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
            }
            GlowText("LEVEL MAP", Neon.Purple, 22)
            Chip("● ${store.coins}", Neon.Yellow)
        }
    }
}

// ------------------------------------------------------------------ Settings dialog
@Composable
fun SettingsPanel(store: GameStore, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xCC000000)).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
        Column(
            Modifier.padding(28.dp).neonGlow(Neon.Cyan, 24.dp).clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF14102B)).clickable(enabled = false) {}.padding(24.dp)
        ) {
            GlowText("SETTINGS", Neon.Cyan, 24)
            Spacer(Modifier.height(16.dp))
            SettingRow("Sound", store.soundOn) { store.setSound(it) }
            SettingRow("Haptics", store.hapticOn) { store.setHaptic(it) }
            SettingRow("Mic audio in recordings", store.micAudio) { store.setMic(it) }
            Spacer(Modifier.height(18.dp))
            NeonButton("CLOSE", Neon.Cyan, onClose, Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun SettingRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween) {
        Text(label, color = Color.White, fontSize = 16.sp, modifier = Modifier.width(190.dp))
        Switch(value, onChange, colors = SwitchDefaults.colors(checkedTrackColor = Neon.Cyan, checkedThumbColor = Color.White))
    }
}

// ------------------------------------------------------------------ small canvas-drawn camera icon
@Composable
fun CameraIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(26.dp)) {
        val w = size.width; val h = size.height
        drawRoundRect(color, Offset(0f, h * 0.22f), Size(w * 0.68f, h * 0.56f), CornerRadius(w * 0.12f))
        val p = Path()
        p.moveTo(w * 0.72f, h * 0.45f); p.lineTo(w, h * 0.25f); p.lineTo(w, h * 0.75f); p.lineTo(w * 0.72f, h * 0.55f); p.close()
        drawPath(p, color)
    }
}

package com.satisfying.slicegame.asmr

import kotlin.math.min

private fun c(v: Long) = v.toInt()

enum class Material(
    val label: String, val top: Int, val bottom: Int, val accent: Int,
    val bounce: Float, val sep: Float, val cutSound: Snd, val rate: Float
) {
    SOAP("Soap Block", c(0xFFFFB3E6), c(0xFFB388FF), c(0xFFFFFFFF), 0.12f, 3.2f, Snd.CUT_SOAP, 1f),
    SAND("Kinetic Sand", c(0xFFF2D49B), c(0xFFC9A064), c(0xFFFFF1C9), 0f, 1.2f, Snd.CUT_SAND, 1f),
    JELLY("Jelly Cube", c(0xFF5CFFB1), c(0xFF14B88A), c(0xFFC8FFE9), 0.55f, 2.4f, Snd.SQUISH, 1.2f),
    CRYSTAL("Crystal Fruit", c(0xFFFF6B9A), c(0xFFFFC857), c(0xFFFFFFFF), 0.2f, 5f, Snd.CRUNCH, 1.3f),
    CLAY("Clay Slime", c(0xFF7DE3FF), c(0xFF3D6BFF), c(0xFFD9F6FF), 0f, 1f, Snd.SQUISH, 0.8f),
    WOOD("Wood", c(0xFFD39A55), c(0xFF8B5A2B), c(0xFFFFE0B0), 0.3f, 2.6f, Snd.CUT_SOAP, 0.7f)
}

enum class Knife(val title: String, val color: Int, val width: Float, val cost: Int, val perfectMin: Float) {
    CLASSIC("Classic", c(0xFF22F0FF), 10f, 0, 0.45f),
    LASER("Laser", c(0xFFFF2E9A), 7f, 50, 0.43f),
    KATANA("Katana", c(0xFFB6FF3B), 12f, 120, 0.41f),
    PLASMA("Plasma", c(0xFFFFD83B), 16f, 250, 0.38f)
}

enum class LevelType(val label: String, val hint: String) {
    SLICE("SLICING SAGA", "Swipe to slice!"),
    SQUISH("SQUISH & STRETCH", "Pinch & stretch with 2 fingers"),
    TAP("TAP & SCRATCH", "Tap for ripples, drag slowly to scratch"),
    CRUNCH("CRUNCH & CRUSH", "Press down from the top to crush"),
    POUR("POUR & DRIP", "Hold to pour - drag or tilt to aim")
}

enum class GoalKind { PIECES, PERFECT_CUTS, SQUISHES, TAPS, CRUSH, FILL }
enum class CrushKind(val label: String) { STAR("stars"), COOKIE("cookies"), CHALK("chalk") }

data class LevelDef(
    val number: Int,
    val type: LevelType,
    val material: Material,
    val goal: GoalKind,
    val target: Int,
    val crush: CrushKind = CrushKind.STAR
) {
    val goalText: String
        get() = when (goal) {
            GoalKind.PIECES -> "Slice into $target pieces"
            GoalKind.PERFECT_CUTS -> "Make $target perfect cuts"
            GoalKind.SQUISHES -> "Stretch & squish $target times"
            GoalKind.TAPS -> "Tap & scratch $target points"
            GoalKind.CRUSH -> "Crush all ${crush.label} ($target)"
            GoalKind.FILL -> "Fill the jar to $target%"
        }
    val tint: Int
        get() = when (type) {
            LevelType.SLICE -> c(0xFF22F0FF)
            LevelType.SQUISH -> c(0xFFB6FF3B)
            LevelType.TAP -> c(0xFFFF2E9A)
            LevelType.CRUNCH -> c(0xFFFFD83B)
            LevelType.POUR -> c(0xFFFF9A3B)
        }
}

object LevelManager {
    const val COUNT = 100
    private val pattern = listOf(
        LevelType.SLICE, LevelType.SLICE, LevelType.SQUISH, LevelType.SLICE, LevelType.TAP,
        LevelType.SLICE, LevelType.CRUNCH, LevelType.SLICE, LevelType.POUR, LevelType.SLICE
    )

    val levels: List<LevelDef> = (1..COUNT).map { build(it) }

    fun get(n: Int): LevelDef = levels[(n - 1).coerceIn(0, COUNT - 1)]

    private fun build(n: Int): LevelDef {
        val type = pattern[(n - 1) % 10]
        val mats = Material.values()
        return when (type) {
            LevelType.SLICE -> {
                val mat = mats[(n + n / 10) % mats.size]
                if ((n / 2) % 3 == 0 && n > 5)
                    LevelDef(n, type, mat, GoalKind.PERFECT_CUTS, min(8, 1 + n / 10))
                else
                    LevelDef(n, type, mat, GoalKind.PIECES, min(8, 2 + n / 7))
            }
            LevelType.SQUISH -> LevelDef(n, type, Material.CLAY, GoalKind.SQUISHES, min(12, 3 + n / 10))
            LevelType.TAP -> LevelDef(n, type, Material.JELLY, GoalKind.TAPS, min(60, 15 + n / 2))
            LevelType.CRUNCH -> LevelDef(
                n, type, Material.WOOD, GoalKind.CRUSH, min(12, 5 + n / 12),
                CrushKind.values()[(n / 10) % 3]
            )
            LevelType.POUR -> LevelDef(n, type, Material.CLAY, GoalKind.FILL, min(100, 60 + n / 3))
        }
    }
}

package com.satisfying.slicegame.asmr

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Local progress + settings (SharedPreferences, fully offline). */
class GameStore(context: Context) {
    private val sp = context.getSharedPreferences("slice_save", Context.MODE_PRIVATE)

    var coins by mutableIntStateOf(sp.getInt("coins", 0)); private set
    var unlocked by mutableIntStateOf(sp.getInt("unlocked", 1)); private set
    var knife by mutableIntStateOf(sp.getInt("knife", 0)); private set
    var knifeMask by mutableIntStateOf(sp.getInt("knifeMask", 1)); private set
    var soundOn by mutableStateOf(sp.getBoolean("sound", true)); private set
    var hapticOn by mutableStateOf(sp.getBoolean("haptic", true)); private set
    var micAudio by mutableStateOf(sp.getBoolean("mic", false)); private set

    fun addCoins(n: Int) { coins += n; sp.edit().putInt("coins", coins).apply() }
    fun stars(level: Int): Int = sp.getInt("stars_$level", 0)
    fun completeLevel(level: Int, stars: Int) {
        if (stars > stars(level)) sp.edit().putInt("stars_$level", stars).apply()
        if (level + 1 > unlocked && level < 100) {
            unlocked = level + 1
            sp.edit().putInt("unlocked", unlocked).apply()
        }
    }
    fun knifeOwned(i: Int) = (knifeMask and (1 shl i)) != 0
    /** Select knife; buys it if affordable. Returns true if now selected. */
    fun chooseKnife(i: Int): Boolean {
        val k = Knife.values()[i]
        if (!knifeOwned(i)) {
            if (coins < k.cost) return false
            coins -= k.cost
            knifeMask = knifeMask or (1 shl i)
            sp.edit().putInt("coins", coins).putInt("knifeMask", knifeMask).apply()
        }
        knife = i
        sp.edit().putInt("knife", i).apply()
        return true
    }
    fun setSound(b: Boolean) { soundOn = b; sp.edit().putBoolean("sound", b).apply() }
    fun setHaptic(b: Boolean) { hapticOn = b; sp.edit().putBoolean("haptic", b).apply() }
    fun setMic(b: Boolean) { micAudio = b; sp.edit().putBoolean("mic", b).apply() }
}

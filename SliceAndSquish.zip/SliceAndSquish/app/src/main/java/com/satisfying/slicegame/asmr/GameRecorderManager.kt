package com.satisfying.slicegame.asmr

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Records ONLY the game canvas (the app's own rendering) to an MP4:
 *  - H.264 via MediaCodec + input Surface, 1080x1920, 60 fps, 20 Mbps
 *  - optional AAC audio from the microphone (needs RECORD_AUDIO; skipped if not granted)
 *  - saved to Movies/SliceGame through MediaStore (scoped storage, no storage permission)
 *
 * Frames are drawn by calling GameWorld.render() on the encoder Surface's canvas,
 * so the video is pixel-identical to what the game draws.
 */
class GameRecorderManager(private val context: Context) {

    companion object {
        const val W = 1080
        const val H = 1920
    }

    var isRecording by mutableStateOf(false); private set
    var startedAtMs by mutableLongStateOf(0L); private set

    private val frameLock = Any()
    private val muxLock = Any()

    private var videoEncoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var audioEncoder: MediaCodec? = null
    private var audioRecord: AudioRecord? = null
    private var muxer: MediaMuxer? = null
    private var tempFile: File? = null

    private var videoThread: Thread? = null
    private var audioThread: Thread? = null
    @Volatile private var audioStop = false

    private var videoTrack = -1
    private var audioTrack = -1
    private var expectedTracks = 1
    private var tracksAdded = 0
    private var muxerStarted = false
    private var startUs = 0L
    private var lastVideoPts = -1L
    private var lastAudioPts = -1L

    private var frameIntervalNs = 16_666_666L
    private var lastFrameNs = 0L

    private class Pending(val video: Boolean, val data: ByteBuffer, val info: MediaCodec.BufferInfo)
    private val pending = ArrayList<Pending>()

    // ------------------------------------------------------------------ start
    fun start(withMic: Boolean): Boolean {
        if (isRecording) return false
        val file = File(context.cacheDir, "rec_${System.currentTimeMillis()}.mp4")
        tempFile = file

        // try 60fps/20Mbps first, then fall back for weaker encoders
        val attempts = listOf(Pair(60, 20_000_000), Pair(30, 16_000_000), Pair(30, 10_000_000))
        var ok = false
        for ((fps, bitrate) in attempts) {
            try {
                setupVideo(fps, bitrate)
                ok = true
                break
            } catch (e: Exception) {
                releaseVideoOnly()
            }
        }
        if (!ok) return false

        try {
            muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        } catch (e: Exception) {
            releaseVideoOnly(); return false
        }

        val micOk = withMic &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        var audioOk = false
        if (micOk) {
            try { setupAudio(); audioOk = true } catch (e: Exception) { releaseAudio() }
        }

        expectedTracks = if (audioOk) 2 else 1
        tracksAdded = 0; videoTrack = -1; audioTrack = -1
        muxerStarted = false; pending.clear()
        lastVideoPts = -1; lastAudioPts = -1
        startUs = System.nanoTime() / 1000L
        audioStop = false

        videoEncoder?.start()
        videoThread = Thread({ drainVideo() }, "rec-video").also { it.start() }
        if (audioOk) {
            audioEncoder?.start()
            audioRecord?.startRecording()
            audioThread = Thread({ audioLoop() }, "rec-audio").also { it.start() }
        }
        lastFrameNs = 0L
        startedAtMs = System.currentTimeMillis()
        isRecording = true
        return true
    }

    private fun setupVideo(fps: Int, bitrate: Int) {
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            if (Build.VERSION.SDK_INT >= 23) setInteger(MediaFormat.KEY_PRIORITY, 0)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        videoEncoder = enc
        enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inputSurface = enc.createInputSurface()
        frameIntervalNs = 1_000_000_000L / fps
    }

    private fun setupAudio() {
        val rate = 44100
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) throw IllegalStateException("audio")
        @Suppress("MissingPermission")
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, minBuf * 4
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); throw IllegalStateException("audio") }
        audioRecord = rec
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        audioEncoder = enc
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
    }

    // ------------------------------------------------------------------ frames
    /** Call once per UI frame (main thread). Draws the game into the encoder surface. */
    fun captureFrame(world: GameWorld) {
        if (!isRecording) return
        val now = System.nanoTime()
        if (now - lastFrameNs < frameIntervalNs - 2_000_000L) return
        lastFrameNs = now
        synchronized(frameLock) {
            if (!isRecording) return
            val s = inputSurface ?: return
            val canvas = try {
                if (Build.VERSION.SDK_INT >= 23) s.lockHardwareCanvas() else s.lockCanvas(null)
            } catch (e: Exception) {
                try { s.lockCanvas(null) } catch (e2: Exception) { return }
            }
            try {
                world.render(canvas, W.toFloat(), H.toFloat())
            } finally {
                try { s.unlockCanvasAndPost(canvas) } catch (e: Exception) { }
            }
        }
    }

    // ------------------------------------------------------------------ threads
    private fun drainVideo() {
        val enc = videoEncoder ?: return
        val info = MediaCodec.BufferInfo()
        try {
            while (true) {
                val idx = enc.dequeueOutputBuffer(info, 10_000)
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    onFormat(true, enc.outputFormat)
                } else if (idx >= 0) {
                    val eos = handleOutput(enc, idx, info, true)
                    if (eos) break
                }
            }
        } catch (e: Exception) { /* encoder released */ }
    }

    private fun audioLoop() {
        val rec = audioRecord ?: return
        val enc = audioEncoder ?: return
        val buf = ByteArray(4096)
        val info = MediaCodec.BufferInfo()
        try {
            while (!audioStop) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) {
                    val inIdx = enc.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val ib = enc.getInputBuffer(inIdx)!!
                        ib.clear(); ib.put(buf, 0, n)
                        val chunkUs = n / 2 * 1_000_000L / 44100L
                        val pts = System.nanoTime() / 1000L - chunkUs
                        enc.queueInputBuffer(inIdx, 0, n, pts, 0)
                    }
                }
                drainAudio(enc, info)
            }
            // EOS
            var queued = false
            for (i in 0 until 50) {
                val inIdx = enc.dequeueInputBuffer(10_000)
                if (inIdx >= 0) {
                    enc.queueInputBuffer(inIdx, 0, 0, System.nanoTime() / 1000L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    queued = true; break
                }
            }
            if (queued) {
                for (i in 0 until 200) {
                    if (drainAudio(enc, info)) break
                    Thread.sleep(5)
                }
            }
        } catch (e: Exception) { }
    }

    /** returns true on EOS */
    private fun drainAudio(enc: MediaCodec, info: MediaCodec.BufferInfo): Boolean {
        while (true) {
            val idx = enc.dequeueOutputBuffer(info, 0)
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) return false
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { onFormat(false, enc.outputFormat); continue }
            if (idx >= 0) { if (handleOutput(enc, idx, info, false)) return true }
        }
    }

    private fun handleOutput(enc: MediaCodec, idx: Int, info: MediaCodec.BufferInfo, video: Boolean): Boolean {
        val buf = enc.getOutputBuffer(idx)
        val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
        val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
        if (buf != null && info.size > 0 && !isConfig) {
            var pts = info.presentationTimeUs - startUs
            if (pts < 0) pts = 0
            if (video) { if (pts <= lastVideoPts) pts = lastVideoPts + 1; lastVideoPts = pts }
            else { if (pts <= lastAudioPts) pts = lastAudioPts + 1; lastAudioPts = pts }
            buf.position(info.offset)
            buf.limit(info.offset + info.size)
            val out = MediaCodec.BufferInfo()
            out.set(info.offset, info.size, pts, info.flags)
            writeSample(video, buf, out)
        }
        enc.releaseOutputBuffer(idx, false)
        return eos
    }

    private fun onFormat(video: Boolean, fmt: MediaFormat) {
        synchronized(muxLock) {
            val m = muxer ?: return
            val t = m.addTrack(fmt)
            if (video) videoTrack = t else audioTrack = t
            tracksAdded++
            if (tracksAdded >= expectedTracks) {
                m.start()
                muxerStarted = true
                for (p in pending) {
                    m.writeSampleData(if (p.video) videoTrack else audioTrack, p.data, p.info)
                }
                pending.clear()
            }
        }
    }

    private fun writeSample(video: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        synchronized(muxLock) {
            val m = muxer ?: return
            if (muxerStarted) {
                m.writeSampleData(if (video) videoTrack else audioTrack, buf, info)
            } else {
                val copy = ByteBuffer.allocate(info.size)
                copy.put(buf); copy.flip()
                val bi = MediaCodec.BufferInfo()
                bi.set(0, info.size, info.presentationTimeUs, info.flags)
                pending.add(Pending(video, copy, bi))
            }
        }
    }

    // ------------------------------------------------------------------ stop
    /** Stops, finalises and saves to the gallery. Call from a background thread. Returns Uri or null. */
    fun stop(): Uri? {
        if (!isRecording) return null
        synchronized(frameLock) {
            isRecording = false
            try { videoEncoder?.signalEndOfInputStream() } catch (e: Exception) { }
        }
        audioStop = true
        try { videoThread?.join(4000) } catch (e: Exception) { }
        try { audioThread?.join(2000) } catch (e: Exception) { }

        synchronized(muxLock) {
            try { if (muxerStarted) muxer?.stop() } catch (e: Exception) { }
            try { muxer?.release() } catch (e: Exception) { }
            muxer = null; muxerStarted = false
        }
        releaseVideoOnly()
        releaseAudio()

        val file = tempFile
        tempFile = null
        if (file == null || !file.exists() || file.length() < 1024) { file?.delete(); return null }
        return saveToGallery(file)
    }

    private fun releaseVideoOnly() {
        try { videoEncoder?.stop() } catch (e: Exception) { }
        try { videoEncoder?.release() } catch (e: Exception) { }
        try { inputSurface?.release() } catch (e: Exception) { }
        videoEncoder = null; inputSurface = null
    }

    private fun releaseAudio() {
        try { audioRecord?.stop() } catch (e: Exception) { }
        try { audioRecord?.release() } catch (e: Exception) { }
        try { audioEncoder?.stop() } catch (e: Exception) { }
        try { audioEncoder?.release() } catch (e: Exception) { }
        audioRecord = null; audioEncoder = null
    }

    // ------------------------------------------------------------------ MediaStore
    private fun saveToGallery(file: File): Uri? {
        val name = "SliceGame_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SliceGame")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
                    ?: return null
                resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                file.delete()
                uri
            } else {
                // Android 7-9: no storage permission requested, so save in the app's own Movies folder.
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
                val dest = File(dir, name)
                file.copyTo(dest, overwrite = true)
                file.delete()
                Uri.fromFile(dest)
            }
        } catch (e: Exception) {
            null
        }
    }
}

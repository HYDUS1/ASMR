package com.satisfying.slicegame.asmr

import androidx.compose.ui.geometry.Offset
import kotlin.math.abs
import kotlin.math.sqrt

/** Infinite line through points a and b. */
data class Line(val a: Offset, val b: Offset)

/**
 * Splits a (convex) polygon by an infinite line.
 * Returns (sideA, sideB). If the line does not really cut the polygon,
 * the second list is empty and the first is the untouched polygon.
 */
fun slicePolygon(polygon: List<Offset>, line: Line): Pair<List<Offset>, List<Offset>> {
    val n = polygon.size
    if (n < 3) return Pair(polygon, emptyList())
    val dx = line.b.x - line.a.x
    val dy = line.b.y - line.a.y
    val len = sqrt(dx * dx + dy * dy)
    if (len < 1e-4f) return Pair(polygon, emptyList())
    val ux = dx / len
    val uy = dy / len
    val eps = 0.01f
    val side = FloatArray(n) {
        val vx = polygon[it].x - line.a.x
        val vy = polygon[it].y - line.a.y
        ux * vy - uy * vx
    }
    val left = ArrayList<Offset>()
    val right = ArrayList<Offset>()
    for (i in 0 until n) {
        val j = (i + 1) % n
        val pi = polygon[i]
        val pj = polygon[j]
        val si = side[i]
        val sj = side[j]
        if (abs(si) <= eps) {
            left.add(pi); right.add(pi)
        } else if (si > 0f) {
            left.add(pi)
        } else {
            right.add(pi)
        }
        if ((si > eps && sj < -eps) || (si < -eps && sj > eps)) {
            val t = si / (si - sj)
            val ip = Offset(pi.x + (pj.x - pi.x) * t, pi.y + (pj.y - pi.y) * t)
            left.add(ip); right.add(ip)
        }
    }
    if (left.size < 3 || right.size < 3) return Pair(polygon, emptyList())
    return Pair(left, right)
}

fun polygonArea(p: List<Offset>): Float {
    var a = 0f
    for (i in p.indices) {
        val j = (i + 1) % p.size
        a += p[i].x * p[j].y - p[j].x * p[i].y
    }
    return abs(a) * 0.5f
}

fun polygonCentroid(p: List<Offset>): Offset {
    var a = 0f
    var cx = 0f
    var cy = 0f
    for (i in p.indices) {
        val j = (i + 1) % p.size
        val cr = p[i].x * p[j].y - p[j].x * p[i].y
        a += cr
        cx += (p[i].x + p[j].x) * cr
        cy += (p[i].y + p[j].y) * cr
    }
    if (abs(a) < 1e-3f) {
        var sx = 0f; var sy = 0f
        for (q in p) { sx += q.x; sy += q.y }
        return Offset(sx / p.size, sy / p.size)
    }
    a *= 0.5f
    return Offset(cx / (6f * a), cy / (6f * a))
}

/** Intersections of segment a-b with polygon boundary, sorted along a->b. */
fun segmentPolygonHits(a: Offset, b: Offset, poly: List<Offset>): List<Offset> {
    val hits = ArrayList<Pair<Float, Offset>>()
    val rx = b.x - a.x
    val ry = b.y - a.y
    for (i in poly.indices) {
        val p = poly[i]
        val q = poly[(i + 1) % poly.size]
        val sx = q.x - p.x
        val sy = q.y - p.y
        val den = rx * sy - ry * sx
        if (abs(den) < 1e-6f) continue
        val qpx = p.x - a.x
        val qpy = p.y - a.y
        val t = (qpx * sy - qpy * sx) / den
        val u = (qpx * ry - qpy * rx) / den
        if (t in 0f..1f && u in 0f..1f) {
            hits.add(Pair(t, Offset(a.x + rx * t, a.y + ry * t)))
        }
    }
    hits.sortBy { it.first }
    // drop duplicate hits (vertex touches)
    val out = ArrayList<Offset>()
    for (h in hits) {
        if (out.isEmpty() || (out.last() - h.second).getDistance() > 1.5f) out.add(h.second)
    }
    return out
}
